<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['product']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['product']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $product_data = json_encode([
        'id' => $product->id,
        'name' => $product->name,
        'price' => $product->base_price,
        'image' => $product->hasMedia('product_image')
            ? $product->getFirstMediaUrl('product_image', 'thumbnail')
            : 'https://placehold.net/400x400.png',
    ]);
?>

<button type="button" class="add-to-cart-btn btn border border-secondary rounded-pill px-3 text-primary"
    data-product="<?php echo e($product_data); ?>"><i class="fa fa-shopping-bag me-2 text-primary"></i> Add to
    cart
</button>
<?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views\components\frontend\buttons\add-to-card.blade.php ENDPATH**/ ?>