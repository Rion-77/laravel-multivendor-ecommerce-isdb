

<?php $__env->startSection('title', 'Edit Category'); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/filepond.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main class="app-main" id="main" tabindex="-1">

        <?php if (isset($component)) { $__componentOriginalf97de8cc237fb2376b7c7401879ba866 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf97de8cc237fb2376b7c7401879ba866 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.content-header','data' => ['title' => 'Product Categories']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.content-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Product Categories']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf97de8cc237fb2376b7c7401879ba866)): ?>
<?php $attributes = $__attributesOriginalf97de8cc237fb2376b7c7401879ba866; ?>
<?php unset($__attributesOriginalf97de8cc237fb2376b7c7401879ba866); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf97de8cc237fb2376b7c7401879ba866)): ?>
<?php $component = $__componentOriginalf97de8cc237fb2376b7c7401879ba866; ?>
<?php unset($__componentOriginalf97de8cc237fb2376b7c7401879ba866); ?>
<?php endif; ?>

        <div class="app-content">
            <div class="container-fluid">

                <?php if (isset($component)) { $__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.success-flash-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.success-flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4)): ?>
<?php $attributes = $__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4; ?>
<?php unset($__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4)): ?>
<?php $component = $__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4; ?>
<?php unset($__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4); ?>
<?php endif; ?>

                <div class="row">
                    <div class="col-lg-4">
                        <div class="card card-primary card-outline">
                            <div class="card-header">
                                <h3 class="card-title">Edit Category</h3>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(route('admin.categories.update', $category)); ?>" method="POST"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    <?php if (isset($component)) { $__componentOriginal375f0ed4f8ee156e823aad8b1382f853 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal375f0ed4f8ee156e823aad8b1382f853 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form.input','data' => ['class' => 'col-12','label' => 'Category name','type' => 'text','placeholder' => 'e.g. Home Appliances','name' => 'name','value' => ''.e(old('name', $category->name)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-12','label' => 'Category name','type' => 'text','placeholder' => 'e.g. Home Appliances','name' => 'name','value' => ''.e(old('name', $category->name)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal375f0ed4f8ee156e823aad8b1382f853)): ?>
<?php $attributes = $__attributesOriginal375f0ed4f8ee156e823aad8b1382f853; ?>
<?php unset($__attributesOriginal375f0ed4f8ee156e823aad8b1382f853); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal375f0ed4f8ee156e823aad8b1382f853)): ?>
<?php $component = $__componentOriginal375f0ed4f8ee156e823aad8b1382f853; ?>
<?php unset($__componentOriginal375f0ed4f8ee156e823aad8b1382f853); ?>
<?php endif; ?>

                                    <div class="mb-3">
                                        <label class="form-label" for="category_icon">Category Icon</label>
                                        <?php if($category->hasMedia('category_icon')): ?>
                                            <div class="mb-2">
                                                <img src="<?php echo e($category->getFirstMediaUrl('category_icon')); ?>"
                                                    alt="<?php echo e($category->name); ?> icon" style="width: 50px; height: auto;">
                                            </div>
                                        <?php endif; ?>
                                        <input type="file" id="category_icon" class="filepond"
                                            name="category_icon">
                                        <p class="text-secondary fs-7 mt-2 mb-0">Optional. Image Only, up to 2MB.</p>
                                        <?php if (isset($component)) { $__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.error-message','data' => ['name' => 'category_icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.error-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'category_icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78)): ?>
<?php $attributes = $__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78; ?>
<?php unset($__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78)): ?>
<?php $component = $__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78; ?>
<?php unset($__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78); ?>
<?php endif; ?>
                                    </div>

                                    <div class="d-flex gap-2">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="bi bi-check-lg me-1"></i>Update Category
                                        </button>
                                        <a href="<?php echo e(route('admin.categories.index')); ?>"
                                            class="btn btn-outline-secondary">Cancel</a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>