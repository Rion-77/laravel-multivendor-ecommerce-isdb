<?php $__env->startSection('content'); ?>
    <div class="container-fluid page-header py-5">
        <h1 class="text-center text-white display-6">Our Vendors</h1>
        <ol class="breadcrumb justify-content-center mb-0">
            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
            <li class="breadcrumb-item"><a href="#">Pages</a></li>
            <li class="breadcrumb-item active text-white">Vendors</li>
        </ol>
    </div>
    <!-- Single Page Header End -->


    <!-- Vendors Directory Start -->
    <div class="container-fluid fruite py-5">
        <div class="container py-5">
            <div class="row g-4 mb-4">
                <div class="col-lg-4 text-start">
                    <h1 class="mb-0">Our Vendors</h1>
                    <p class="mb-0">Browse 10+ verified sellers on Fruitables</p>
                </div>
                <div class="col-lg-4">
                    <div class="input-group w-100 mx-auto d-flex">
                        <input type="search" class="form-control p-3" placeholder="Search vendors"
                            aria-describedby="search-icon-1">
                        <span id="search-icon-1" class="input-group-text p-3"><i class="fa fa-search"></i></span>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="bg-light ps-3 py-3 rounded d-flex justify-content-between">
                        <label for="sortlist">Sort By:</label>
                        <select id="sortlist" name="sortlist" class="border-0 form-select-sm bg-light me-3">
                            <option>Most Popular</option>
                            <option>Top Rated</option>
                            <option>Newest</option>
                            <option>Most Products</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row g-4">
                <?php $__empty_1 = true; $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if (isset($component)) { $__componentOriginal386abea58736bc96034eeb9bf47c8d2b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal386abea58736bc96034eeb9bf47c8d2b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.vendor-card','data' => ['vendor' => $vendor,'class' => 'col-md-6 col-lg-4 col-xl-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.vendor-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['vendor' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($vendor),'class' => 'col-md-6 col-lg-4 col-xl-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal386abea58736bc96034eeb9bf47c8d2b)): ?>
<?php $attributes = $__attributesOriginal386abea58736bc96034eeb9bf47c8d2b; ?>
<?php unset($__attributesOriginal386abea58736bc96034eeb9bf47c8d2b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal386abea58736bc96034eeb9bf47c8d2b)): ?>
<?php $component = $__componentOriginal386abea58736bc96034eeb9bf47c8d2b; ?>
<?php unset($__componentOriginal386abea58736bc96034eeb9bf47c8d2b); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php if (isset($component)) { $__componentOriginalc16dbe39dee1dac23ab3d25c192057d7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc16dbe39dee1dac23ab3d25c192057d7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.no-data','data' => ['text' => 'No vendor found...']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.no-data'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => 'No vendor found...']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc16dbe39dee1dac23ab3d25c192057d7)): ?>
<?php $attributes = $__attributesOriginalc16dbe39dee1dac23ab3d25c192057d7; ?>
<?php unset($__attributesOriginalc16dbe39dee1dac23ab3d25c192057d7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc16dbe39dee1dac23ab3d25c192057d7)): ?>
<?php $component = $__componentOriginalc16dbe39dee1dac23ab3d25c192057d7; ?>
<?php unset($__componentOriginalc16dbe39dee1dac23ab3d25c192057d7); ?>
<?php endif; ?>
                <?php endif; ?>
            </div>
            <?php if (isset($component)) { $__componentOriginal5ca54a1fa2415d436a7e52d382580d30 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5ca54a1fa2415d436a7e52d382580d30 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.pagination','data' => ['for' => $vendors]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($vendors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5ca54a1fa2415d436a7e52d382580d30)): ?>
<?php $attributes = $__attributesOriginal5ca54a1fa2415d436a7e52d382580d30; ?>
<?php unset($__attributesOriginal5ca54a1fa2415d436a7e52d382580d30); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ca54a1fa2415d436a7e52d382580d30)): ?>
<?php $component = $__componentOriginal5ca54a1fa2415d436a7e52d382580d30; ?>
<?php unset($__componentOriginal5ca54a1fa2415d436a7e52d382580d30); ?>
<?php endif; ?>
        </div>
    </div>
    <!-- Vendors Directory End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views\frontend\vendors\index.blade.php ENDPATH**/ ?>