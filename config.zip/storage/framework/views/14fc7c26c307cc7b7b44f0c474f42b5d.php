<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['itemName', 'itemDeleteUrl']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['itemName', 'itemDeleteUrl']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<button type="button" class="delete-btn btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#modal-delete-item"
    data-item-name = "<?php echo e($itemName); ?>" data-item-delete-url = "<?php echo e($itemDeleteUrl); ?>">
    <i class="bi bi-trash"> </i>
</button>
<?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views\components\admin\buttons\delete.blade.php ENDPATH**/ ?>