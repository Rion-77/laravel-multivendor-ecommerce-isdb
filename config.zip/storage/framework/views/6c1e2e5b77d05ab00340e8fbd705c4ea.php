<?php $__env->startSection('content'); ?>
    <!-- Single Page Header start -->
    <div class="container-fluid page-header py-5">
        <h1 class="text-center text-white display-6">Vendor Store</h1>
        <ol class="breadcrumb justify-content-center mb-0">
            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
            <li class="breadcrumb-item"><a href="vendors.html">Vendors</a></li>
            <li class="breadcrumb-item active text-white">Green Valley Farms</li>
        </ol>
    </div>
    <!-- Single Page Header End -->


    <!-- Vendor Storefront Start -->
    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="position-relative mb-5">
                
                <div class="d-flex flex-wrap align-items-center justify-content-between px-3">
                    <div class="d-flex align-items-center">
                        <img src="<?php echo e($vendor->hasMedia('shop_logo') ? $vendor->getFirstMediaUrl('shop_logo', 'logo') : 'https://picsum.photos/200/200'); ?>"
                            class="vendor-profile-logo" alt="" style="margin-top: 0;">
                        <div class="ms-4 mb-2">
                            <h2 class="mb-1"><?php echo e($vendor->shop_name); ?><i class="fas fa-check-circle vendor-badge-verified"
                                    title="Verified Vendor"></i></h2>
                            
                        </div>
                    </div>
                    <div>
                        <div class="d-flex gap-2">
                            
                                <div class="stat-pill">
                                    <h3><?php echo e($vendor->products()->count()); ?></h3>
                                    <p class="mb-0">Products</p>
                                </div>
                           
                            
                                <div class="stat-pill">
                                    <h3>4.5 <i class="fas fa-star text-secondary" style="font-size: 18px;"></i></h3>
                                    <p class="mb-0">1,240 Ratings</p>
                                </div>
                            


                        </div>
                    </div>
                </div>
            </div>



            <nav>
                <div class="nav nav-tabs mb-4">
                    <button class="nav-link active border-white border-bottom-0" type="button" role="tab"
                        data-bs-toggle="tab" data-bs-target="#nav-products">Products</button>
                    <button class="nav-link border-white border-bottom-0" type="button" role="tab" data-bs-toggle="tab"
                        data-bs-target="#nav-about-vendor">About</button>
                    <button class="nav-link border-white border-bottom-0" type="button" role="tab" data-bs-toggle="tab"
                        data-bs-target="#nav-vendor-reviews">Reviews</button>
                </div>
            </nav>
            <div class="tab-content">
                <div class="tab-pane active" id="nav-products" role="tabpanel">
                    <div class="row g-4">
                        
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php if (isset($component)) { $__componentOriginal53cd2fde3c8be4bcfe76ede478d3a538 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53cd2fde3c8be4bcfe76ede478d3a538 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.products.card','data' => ['product' => $product,'class' => 'col-md-6 col-lg-6 col-xl-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.products.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product),'class' => 'col-md-6 col-lg-6 col-xl-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53cd2fde3c8be4bcfe76ede478d3a538)): ?>
<?php $attributes = $__attributesOriginal53cd2fde3c8be4bcfe76ede478d3a538; ?>
<?php unset($__attributesOriginal53cd2fde3c8be4bcfe76ede478d3a538); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53cd2fde3c8be4bcfe76ede478d3a538)): ?>
<?php $component = $__componentOriginal53cd2fde3c8be4bcfe76ede478d3a538; ?>
<?php unset($__componentOriginal53cd2fde3c8be4bcfe76ede478d3a538); ?>
<?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php if (isset($component)) { $__componentOriginalc16dbe39dee1dac23ab3d25c192057d7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc16dbe39dee1dac23ab3d25c192057d7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.no-data','data' => ['text' => 'No products found...']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.no-data'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => 'No products found...']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc16dbe39dee1dac23ab3d25c192057d7)): ?>
<?php $attributes = $__attributesOriginalc16dbe39dee1dac23ab3d25c192057d7; ?>
<?php unset($__attributesOriginalc16dbe39dee1dac23ab3d25c192057d7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc16dbe39dee1dac23ab3d25c192057d7)): ?>
<?php $component = $__componentOriginalc16dbe39dee1dac23ab3d25c192057d7; ?>
<?php unset($__componentOriginalc16dbe39dee1dac23ab3d25c192057d7); ?>
<?php endif; ?>
                        <?php endif; ?>

                    </div>
                    <?php if (isset($component)) { $__componentOriginal5ca54a1fa2415d436a7e52d382580d30 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5ca54a1fa2415d436a7e52d382580d30 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.pagination','data' => ['for' => $products]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($products)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5ca54a1fa2415d436a7e52d382580d30)): ?>
<?php $attributes = $__attributesOriginal5ca54a1fa2415d436a7e52d382580d30; ?>
<?php unset($__attributesOriginal5ca54a1fa2415d436a7e52d382580d30); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ca54a1fa2415d436a7e52d382580d30)): ?>
<?php $component = $__componentOriginal5ca54a1fa2415d436a7e52d382580d30; ?>
<?php unset($__componentOriginal5ca54a1fa2415d436a7e52d382580d30); ?>
<?php endif; ?>
                    
                </div>
                <div class="tab-pane" id="nav-about-vendor" role="tabpanel">
                    <p><?php echo e($vendor->description); ?></p>
                    
                </div>
                <div class="tab-pane" id="nav-vendor-reviews" role="tabpanel">
                    <div class="d-flex">
                        <img src="img/avatar.jpg" class="img-fluid rounded-circle p-3" style="width: 100px; height: 100px;"
                            alt="">
                        <div class="">
                            <p class="mb-2" style="font-size: 14px;">April 12, 2026</p>
                            <div class="d-flex justify-content-between">
                                <h5>Jason Smith</h5>
                                <div class="d-flex mb-3">
                                    <i class="fa fa-star text-secondary"></i><i class="fa fa-star text-secondary"></i><i
                                        class="fa fa-star text-secondary"></i><i class="fa fa-star text-secondary"></i><i
                                        class="fa fa-star"></i>
                                </div>
                            </div>
                            <p>Consistently fresh produce and fast shipping. This is my go-to vendor for weekly groceries.
                            </p>
                        </div>
                    </div>
                    <div class="d-flex">
                        <img src="img/avatar.jpg" class="img-fluid rounded-circle p-3" style="width: 100px; height: 100px;"
                            alt="">
                        <div class="">
                            <p class="mb-2" style="font-size: 14px;">March 28, 2026</p>
                            <div class="d-flex justify-content-between">
                                <h5>Sam Peters</h5>
                                <div class="d-flex mb-3">
                                    <i class="fa fa-star text-secondary"></i><i class="fa fa-star text-secondary"></i><i
                                        class="fa fa-star text-secondary"></i><i class="fa fa-star text-secondary"></i><i
                                        class="fa fa-star"></i>
                                </div>
                            </div>
                            <p class="text-dark">Great packaging, produce always arrives in great shape.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Vendor Storefront End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views\frontend\vendors\show.blade.php ENDPATH**/ ?>