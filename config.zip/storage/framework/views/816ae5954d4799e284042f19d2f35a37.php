<?php
    use App\Enums\ProductStatus;
?>



<?php $__env->startSection('title', 'Add Product'); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        @media (min-width: 50em) {
            .filepond--item {
                width: calc(33.33% - 0.5em);
            }
        }

        /* Enable a 2-column horizontal layout on medium screens/tablets */
        @media (min-width: 30em) and (max-width: 50em) {
            .filepond--item {
                width: calc(50% - 0.5em);
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/filepond.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main class="app-main" id="main" tabindex="-1">

        <?php if (isset($component)) { $__componentOriginalf97de8cc237fb2376b7c7401879ba866 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf97de8cc237fb2376b7c7401879ba866 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.content-header','data' => ['title' => 'Add / Edit Product']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.content-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Add / Edit Product']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf97de8cc237fb2376b7c7401879ba866)): ?>
<?php $attributes = $__attributesOriginalf97de8cc237fb2376b7c7401879ba866; ?>
<?php unset($__attributesOriginalf97de8cc237fb2376b7c7401879ba866); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf97de8cc237fb2376b7c7401879ba866)): ?>
<?php $component = $__componentOriginalf97de8cc237fb2376b7c7401879ba866; ?>
<?php unset($__componentOriginalf97de8cc237fb2376b7c7401879ba866); ?>
<?php endif; ?>

        <div class="app-content">
            <div class="container-fluid">
                <form action="<?php echo e(route('admin.products.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-8 order-2 order-lg-1">

                            <div class="card card-primary card-outline mb-3">
                                <div class="card-header">
                                    <h3 class="card-title">General Information</h3>
                                </div>
                                <div class="card-body">
                                    <div class="row g-3">
                                        <!-- Product Name -->
                                        <?php if (isset($component)) { $__componentOriginal375f0ed4f8ee156e823aad8b1382f853 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal375f0ed4f8ee156e823aad8b1382f853 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form.input','data' => ['class' => 'col-12','label' => 'Product name','type' => 'text','placeholder' => 'e.g. Wireless Earbuds Pro','name' => 'name','value' => ''.e(old('name')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-12','label' => 'Product name','type' => 'text','placeholder' => 'e.g. Wireless Earbuds Pro','name' => 'name','value' => ''.e(old('name')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal375f0ed4f8ee156e823aad8b1382f853)): ?>
<?php $attributes = $__attributesOriginal375f0ed4f8ee156e823aad8b1382f853; ?>
<?php unset($__attributesOriginal375f0ed4f8ee156e823aad8b1382f853); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal375f0ed4f8ee156e823aad8b1382f853)): ?>
<?php $component = $__componentOriginal375f0ed4f8ee156e823aad8b1382f853; ?>
<?php unset($__componentOriginal375f0ed4f8ee156e823aad8b1382f853); ?>
<?php endif; ?>


                                        <!-- Vendor -->
                                        <?php if(auth()->user()->role_id == 3): ?>
                                            <?php if (isset($component)) { $__componentOriginal8ef619d218616cae7277f2a386a20785 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ef619d218616cae7277f2a386a20785 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form.select','data' => ['class' => 'col-md-6','label' => 'Vendor','name' => 'vendor_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-md-6','label' => 'Vendor','name' => 'vendor_id']); ?>
                                                <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($vendor->id == session('user_vendor_id')): ?>
                                                        <option value="<?php echo e($vendor->id); ?>" selected>
                                                            <?php echo e($vendor->shop_name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ef619d218616cae7277f2a386a20785)): ?>
<?php $attributes = $__attributesOriginal8ef619d218616cae7277f2a386a20785; ?>
<?php unset($__attributesOriginal8ef619d218616cae7277f2a386a20785); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ef619d218616cae7277f2a386a20785)): ?>
<?php $component = $__componentOriginal8ef619d218616cae7277f2a386a20785; ?>
<?php unset($__componentOriginal8ef619d218616cae7277f2a386a20785); ?>
<?php endif; ?>
                                        <?php else: ?>
                                            <?php if (isset($component)) { $__componentOriginal8ef619d218616cae7277f2a386a20785 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ef619d218616cae7277f2a386a20785 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form.select','data' => ['class' => 'col-md-6','label' => 'Vendor','name' => 'vendor_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-md-6','label' => 'Vendor','name' => 'vendor_id']); ?>
                                                <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($vendor->id); ?>" <?php if(old('vendor_id') == $vendor->id): echo 'selected'; endif; ?>>
                                                        <?php echo e($vendor->shop_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ef619d218616cae7277f2a386a20785)): ?>
<?php $attributes = $__attributesOriginal8ef619d218616cae7277f2a386a20785; ?>
<?php unset($__attributesOriginal8ef619d218616cae7277f2a386a20785); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ef619d218616cae7277f2a386a20785)): ?>
<?php $component = $__componentOriginal8ef619d218616cae7277f2a386a20785; ?>
<?php unset($__componentOriginal8ef619d218616cae7277f2a386a20785); ?>
<?php endif; ?>
                                        <?php endif; ?>


                                        <!-- Status -->

                                        <?php if(auth()->user()->role_id == 3): ?>
                                            <?php if (isset($component)) { $__componentOriginal8ef619d218616cae7277f2a386a20785 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ef619d218616cae7277f2a386a20785 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form.select','data' => ['class' => 'col-md-6','label' => 'Status','name' => 'status']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-md-6','label' => 'Status','name' => 'status']); ?>
                                                <option value="pending_review" selected>Pending Review</option>
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ef619d218616cae7277f2a386a20785)): ?>
<?php $attributes = $__attributesOriginal8ef619d218616cae7277f2a386a20785; ?>
<?php unset($__attributesOriginal8ef619d218616cae7277f2a386a20785); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ef619d218616cae7277f2a386a20785)): ?>
<?php $component = $__componentOriginal8ef619d218616cae7277f2a386a20785; ?>
<?php unset($__componentOriginal8ef619d218616cae7277f2a386a20785); ?>
<?php endif; ?>
                                        <?php else: ?>
                                            <?php if (isset($component)) { $__componentOriginal8ef619d218616cae7277f2a386a20785 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ef619d218616cae7277f2a386a20785 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form.select','data' => ['class' => 'col-md-6','label' => 'Status','name' => 'status']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-md-6','label' => 'Status','name' => 'status']); ?>

                                                <?php $__currentLoopData = ProductStatus::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($status->value); ?>"
                                                        <?php echo e(old('status', $product->status->value ?? '') === $status->value ? 'selected' : ''); ?>>
                                                        <?php echo e($status->label()); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ef619d218616cae7277f2a386a20785)): ?>
<?php $attributes = $__attributesOriginal8ef619d218616cae7277f2a386a20785; ?>
<?php unset($__attributesOriginal8ef619d218616cae7277f2a386a20785); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ef619d218616cae7277f2a386a20785)): ?>
<?php $component = $__componentOriginal8ef619d218616cae7277f2a386a20785; ?>
<?php unset($__componentOriginal8ef619d218616cae7277f2a386a20785); ?>
<?php endif; ?>
                                        <?php endif; ?>


                                        <!-- Categoy -->
                                        <?php if (isset($component)) { $__componentOriginal8ef619d218616cae7277f2a386a20785 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ef619d218616cae7277f2a386a20785 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form.select','data' => ['class' => 'col-md-6','label' => 'Category','name' => 'category_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-md-6','label' => 'Category','name' => 'category_id']); ?>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>" <?php if(old('category_id') == $category->id): echo 'selected'; endif; ?>>
                                                    <?php echo e($category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ef619d218616cae7277f2a386a20785)): ?>
<?php $attributes = $__attributesOriginal8ef619d218616cae7277f2a386a20785; ?>
<?php unset($__attributesOriginal8ef619d218616cae7277f2a386a20785); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ef619d218616cae7277f2a386a20785)): ?>
<?php $component = $__componentOriginal8ef619d218616cae7277f2a386a20785; ?>
<?php unset($__componentOriginal8ef619d218616cae7277f2a386a20785); ?>
<?php endif; ?>

                                        <!-- Brand -->
                                        <?php if (isset($component)) { $__componentOriginal8ef619d218616cae7277f2a386a20785 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ef619d218616cae7277f2a386a20785 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form.select','data' => ['class' => 'col-md-6','label' => 'Brand','name' => 'brand_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-md-6','label' => 'Brand','name' => 'brand_id']); ?>
                                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($brand->id); ?>" <?php if(old('brand_id') == $brand->id): echo 'selected'; endif; ?>>
                                                    <?php echo e($brand->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ef619d218616cae7277f2a386a20785)): ?>
<?php $attributes = $__attributesOriginal8ef619d218616cae7277f2a386a20785; ?>
<?php unset($__attributesOriginal8ef619d218616cae7277f2a386a20785); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ef619d218616cae7277f2a386a20785)): ?>
<?php $component = $__componentOriginal8ef619d218616cae7277f2a386a20785; ?>
<?php unset($__componentOriginal8ef619d218616cae7277f2a386a20785); ?>
<?php endif; ?>


                                        <!-- Textarea -->
                                        <?php if (isset($component)) { $__componentOriginal5f8711bac92b9cbfae758724ea0086d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5f8711bac92b9cbfae758724ea0086d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form.textarea','data' => ['class' => 'col-12','label' => 'Description','placeholder' => 'Describe the product features and benefits','name' => 'description','value' => ''.e(old('description')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-12','label' => 'Description','placeholder' => 'Describe the product features and benefits','name' => 'description','value' => ''.e(old('description')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5f8711bac92b9cbfae758724ea0086d0)): ?>
<?php $attributes = $__attributesOriginal5f8711bac92b9cbfae758724ea0086d0; ?>
<?php unset($__attributesOriginal5f8711bac92b9cbfae758724ea0086d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f8711bac92b9cbfae758724ea0086d0)): ?>
<?php $component = $__componentOriginal5f8711bac92b9cbfae758724ea0086d0; ?>
<?php unset($__componentOriginal5f8711bac92b9cbfae758724ea0086d0); ?>
<?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="card card-primary card-outline mb-3">
                                <div class="card-header">
                                    <h3 class="card-title">Pricing &amp; Inventory</h3>
                                </div>
                                <div class="card-body">
                                    <div class="row g-3">

                                        <!-- Price -->
                                        <?php if (isset($component)) { $__componentOriginal375f0ed4f8ee156e823aad8b1382f853 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal375f0ed4f8ee156e823aad8b1382f853 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form.input','data' => ['class' => 'col-md-6','label' => 'Price','type' => 'number','name' => 'base_price','value' => ''.e(old('base_price')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-md-6','label' => 'Price','type' => 'number','name' => 'base_price','value' => ''.e(old('base_price')).'']); ?>$ <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal375f0ed4f8ee156e823aad8b1382f853)): ?>
<?php $attributes = $__attributesOriginal375f0ed4f8ee156e823aad8b1382f853; ?>
<?php unset($__attributesOriginal375f0ed4f8ee156e823aad8b1382f853); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal375f0ed4f8ee156e823aad8b1382f853)): ?>
<?php $component = $__componentOriginal375f0ed4f8ee156e823aad8b1382f853; ?>
<?php unset($__componentOriginal375f0ed4f8ee156e823aad8b1382f853); ?>
<?php endif; ?>

                                        <!-- Offer Price -->
                                        <?php if (isset($component)) { $__componentOriginal375f0ed4f8ee156e823aad8b1382f853 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal375f0ed4f8ee156e823aad8b1382f853 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form.input','data' => ['class' => 'col-md-6','label' => 'Offer Price','type' => 'number','name' => 'offer_price','value' => ''.e(old('offer_price')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-md-6','label' => 'Offer Price','type' => 'number','name' => 'offer_price','value' => ''.e(old('offer_price')).'']); ?>$ <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal375f0ed4f8ee156e823aad8b1382f853)): ?>
<?php $attributes = $__attributesOriginal375f0ed4f8ee156e823aad8b1382f853; ?>
<?php unset($__attributesOriginal375f0ed4f8ee156e823aad8b1382f853); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal375f0ed4f8ee156e823aad8b1382f853)): ?>
<?php $component = $__componentOriginal375f0ed4f8ee156e823aad8b1382f853; ?>
<?php unset($__componentOriginal375f0ed4f8ee156e823aad8b1382f853); ?>
<?php endif; ?>





                                    </div>
                                </div>
                            </div>



                            <div class="d-flex gap-2">
                                <?php if (isset($component)) { $__componentOriginal59d11a6e74be5400c60dfb05028027c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal59d11a6e74be5400c60dfb05028027c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.buttons.submit','data' => ['label' => 'Save
                                    Product']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.buttons.submit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Save
                                    Product']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal59d11a6e74be5400c60dfb05028027c0)): ?>
<?php $attributes = $__attributesOriginal59d11a6e74be5400c60dfb05028027c0; ?>
<?php unset($__attributesOriginal59d11a6e74be5400c60dfb05028027c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal59d11a6e74be5400c60dfb05028027c0)): ?>
<?php $component = $__componentOriginal59d11a6e74be5400c60dfb05028027c0; ?>
<?php unset($__componentOriginal59d11a6e74be5400c60dfb05028027c0); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginale7ee02212006f2897c542f438fc1313b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale7ee02212006f2897c542f438fc1313b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.buttons.cancel','data' => ['href' => ''.e(route('admin.products.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.buttons.cancel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.products.index')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale7ee02212006f2897c542f438fc1313b)): ?>
<?php $attributes = $__attributesOriginale7ee02212006f2897c542f438fc1313b; ?>
<?php unset($__attributesOriginale7ee02212006f2897c542f438fc1313b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale7ee02212006f2897c542f438fc1313b)): ?>
<?php $component = $__componentOriginale7ee02212006f2897c542f438fc1313b; ?>
<?php unset($__componentOriginale7ee02212006f2897c542f438fc1313b); ?>
<?php endif; ?>
                            </div>

                        </div>

                        <div class="col-lg-4 order-1 order-lg-2">
                            <div class="card card-outline card-primary mb-3">
                                <div class="card-header">
                                    <h3 class="card-title">Product Image</h3>
                                </div>
                                <div class="card-body">
                                    <input type="file" id="product_image" class="filepond" accept="image/*"
                                        name="product_image[]" multiple>
                                    <p class="text-secondary fs-7 mt-2 mb-0">Optional. Image Only, up to 2MB.</p>
                                    <?php if (isset($component)) { $__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.error-message','data' => ['name' => 'product_image']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.error-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'product_image']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78)): ?>
<?php $attributes = $__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78; ?>
<?php unset($__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78)): ?>
<?php $component = $__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78; ?>
<?php unset($__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78); ?>
<?php endif; ?>
                                </div>
                            </div>
                        </div>


                    </div>
                </form>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views\admin\products\create.blade.php ENDPATH**/ ?>