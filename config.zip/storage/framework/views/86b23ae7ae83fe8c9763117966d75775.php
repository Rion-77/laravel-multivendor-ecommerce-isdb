<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        /* Firefox */
        input[type=number] {
            -moz-appearance: textfield;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Single Page Header start -->
    <div class="container-fluid page-header py-5">
        <h1 class="text-center text-white display-6">Shop Detail</h1>
        <ol class="breadcrumb justify-content-center mb-0">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item"><a href="#">Pages</a></li>
            <li class="breadcrumb-item active text-white">Shop Detail</li>
        </ol>
    </div>
    <!-- Single Page Header End -->


    <!-- Single Product Start -->
    <div class="container-fluid py-5 mt-5">
        <div class="container py-5">
            <div class="row g-4 mb-5">
                <div class="col-lg-8 col-xl-9">
                    <div class="row g-4">
                        <div class="col-lg-6">
                            <div class="border rounded">
                                <a href="#">
                                    <?php if($product->hasMedia('product_image')): ?>
                                        <img src="<?php echo e($product->getFirstMediaUrl('product_image')); ?>"
                                            class="img-fluid rounded" alt="">
                                    <?php else: ?>
                                        <img src="https://picsum.photos/500/<?php echo e($product->id + 500); ?>"
                                            class="img-fluid rounded">
                                    <?php endif; ?>
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <h4 class="fw-bold mb-3"><?php echo e($product->name); ?></h4>
                            <p class="mb-3">Category: <?php echo e($product->category->name); ?></p>
                            <div class="sold-by mb-2"><i class="fas fa-store me-1"></i>Sold by <a
                                    href="vendor-detail.html"><?php echo e($product->vendor->shop_name); ?></a> <span
                                    class="text-primary ms-1"><i class="fas fa-check-circle"></i> Verified Vendor</span>
                            </div>
                            <h5 class="fw-bold mb-3"><?php echo e((int) $product->base_price); ?>tk</h5>
                            <div class="d-flex mb-4">
                                <i class="fa fa-star text-secondary"></i>
                                <i class="fa fa-star text-secondary"></i>
                                <i class="fa fa-star text-secondary"></i>
                                <i class="fa fa-star text-secondary"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <p class="mb-4">
                                <?php echo e($product->description); ?>

                            </p>
                            <div class="input-group quantity mb-5" style="width: 100px;">
                                <div class="input-group-btn">
                                    <button class="btn btn-sm btn-minus rounded-circle bg-light border">
                                        <i class="fa fa-minus"></i>
                                    </button>
                                </div>
                                <input type="number"
                                    class="form-control form-control-sm text-center border-0 cart-item-input"
                                    value="1">
                                <div class="input-group-btn">
                                    <button class="btn btn-sm btn-plus rounded-circle bg-light border">
                                        <i class="fa fa-plus"></i>
                                    </button>
                                </div>
                            </div>
                            <!-- Add to Cart Button -->
                            <?php if (isset($component)) { $__componentOriginal304a67fe19a5cff26234eb3d57b66438 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal304a67fe19a5cff26234eb3d57b66438 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.buttons.add-to-card','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.buttons.add-to-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal304a67fe19a5cff26234eb3d57b66438)): ?>
<?php $attributes = $__attributesOriginal304a67fe19a5cff26234eb3d57b66438; ?>
<?php unset($__attributesOriginal304a67fe19a5cff26234eb3d57b66438); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal304a67fe19a5cff26234eb3d57b66438)): ?>
<?php $component = $__componentOriginal304a67fe19a5cff26234eb3d57b66438; ?>
<?php unset($__componentOriginal304a67fe19a5cff26234eb3d57b66438); ?>
<?php endif; ?>
                        </div>
                        <div class="col-lg-12">
                            <nav>
                                <div class="nav nav-tabs mb-3">
                                    <button class="nav-link active border-white border-bottom-0" type="button"
                                        role="tab" id="nav-about-tab" data-bs-toggle="tab" data-bs-target="#nav-about"
                                        aria-controls="nav-about" aria-selected="true">Description</button>
                                    <button class="nav-link border-white border-bottom-0" type="button" role="tab"
                                        id="nav-mission-tab" data-bs-toggle="tab" data-bs-target="#nav-mission"
                                        aria-controls="nav-mission" aria-selected="false">Reviews</button>
                                </div>
                            </nav>
                            <div class="tab-content mb-5">
                                <div class="tab-pane active" id="nav-about" role="tabpanel" aria-labelledby="nav-about-tab">
                                    <?php echo e($product->description); ?>

                                </div>
                                <div class="tab-pane" id="nav-mission" role="tabpanel" aria-labelledby="nav-mission-tab">
                                    <div class="d-flex">
                                        <img src="<?php echo e(asset('img/avatar.jpg')); ?>" class="img-fluid rounded-circle p-3"
                                            style="width: 100px; height: 100px;" alt="">
                                        <div class="">
                                            <p class="mb-2" style="font-size: 14px;">April 12, 2024</p>
                                            <div class="d-flex justify-content-between">
                                                <h5>Jason Smith</h5>
                                                <div class="d-flex mb-3">
                                                    <i class="fa fa-star text-secondary"></i>
                                                    <i class="fa fa-star text-secondary"></i>
                                                    <i class="fa fa-star text-secondary"></i>
                                                    <i class="fa fa-star text-secondary"></i>
                                                    <i class="fa fa-star"></i>
                                                </div>
                                            </div>
                                            <p>The generated Lorem Ipsum is therefore always free from repetition injected
                                                humour, or non-characteristic
                                                words etc. Susp endisse ultricies nisi vel quam suscipit </p>
                                        </div>
                                    </div>
                                    <div class="d-flex">
                                        <img src="<?php echo e(asset('img/avatar.jpg')); ?>" class="img-fluid rounded-circle p-3"
                                            style="width: 100px; height: 100px;" alt="">
                                        <div class="">
                                            <p class="mb-2" style="font-size: 14px;">April 12, 2024</p>
                                            <div class="d-flex justify-content-between">
                                                <h5>Sam Peters</h5>
                                                <div class="d-flex mb-3">
                                                    <i class="fa fa-star text-secondary"></i>
                                                    <i class="fa fa-star text-secondary"></i>
                                                    <i class="fa fa-star text-secondary"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                </div>
                                            </div>
                                            <p class="text-dark">The generated Lorem Ipsum is therefore always free from
                                                repetition injected humour, or non-characteristic
                                                words etc. Susp endisse ultricies nisi vel quam suscipit </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane" id="nav-vision" role="tabpanel">
                                    <p class="text-dark">Tempor erat elitr rebum at clita. Diam dolor diam ipsum et tempor
                                        sit. Aliqu diam
                                        amet diam et eos labore. 3</p>
                                    <p class="mb-0">Diam dolor diam ipsum et tempor sit. Aliqu diam amet diam et eos
                                        labore.
                                        Clita erat ipsum et lorem et sit</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <form action="#">
                                <h4 class="mb-5 fw-bold">Leave a Reply</h4>
                                <div class="row g-4">
                                    <div class="col-lg-6">
                                        <div class="border-bottom rounded">
                                            <input type="text" class="form-control border-0 me-4"
                                                placeholder="Yur Name *">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="border-bottom rounded">
                                            <input type="email" class="form-control border-0"
                                                placeholder="Your Email *">
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="border-bottom rounded my-4">
                                            <textarea name="" id="" class="form-control border-0" cols="30" rows="8"
                                                placeholder="Your Review *" spellcheck="false"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="d-flex justify-content-between py-3 mb-5">
                                            <div class="d-flex align-items-center">
                                                <p class="mb-0 me-3">Please rate:</p>
                                                <div class="d-flex align-items-center" style="font-size: 12px;">
                                                    <i class="fa fa-star text-muted"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                </div>
                                            </div>
                                            <a href="#"
                                                class="btn border border-secondary text-primary rounded-pill px-4 py-3">
                                                Post Comment</a>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-xl-3">
                    <div class="row g-4 fruite">
                        <div class="col-lg-12">
                            <div class="input-group w-100 mx-auto d-flex mb-4">
                                <input type="search" class="form-control p-3" placeholder="keywords"
                                    aria-describedby="search-icon-1">
                                <span id="search-icon-1" class="input-group-text p-3"><i class="fa fa-search"></i></span>
                            </div>
                            <!-- Vendor Card -->
                            
                            <?php if (isset($component)) { $__componentOriginal386abea58736bc96034eeb9bf47c8d2b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal386abea58736bc96034eeb9bf47c8d2b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.vendor-card','data' => ['vendor' => $vendor,'class' => 'col-12 mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.vendor-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['vendor' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($vendor),'class' => 'col-12 mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal386abea58736bc96034eeb9bf47c8d2b)): ?>
<?php $attributes = $__attributesOriginal386abea58736bc96034eeb9bf47c8d2b; ?>
<?php unset($__attributesOriginal386abea58736bc96034eeb9bf47c8d2b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal386abea58736bc96034eeb9bf47c8d2b)): ?>
<?php $component = $__componentOriginal386abea58736bc96034eeb9bf47c8d2b; ?>
<?php unset($__componentOriginal386abea58736bc96034eeb9bf47c8d2b); ?>
<?php endif; ?>
                            <!-- Categories -->
                            <div class="mb-4">
                                <h4>Categories</h4>
                                <ul class="list-unstyled fruite-categorie">
                                    <li>
                                        <div class="d-flex justify-content-between fruite-name">
                                            <a href="#"><i class="fas fa-apple-alt me-2"></i>Apples</a>
                                            <span>(3)</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="d-flex justify-content-between fruite-name">
                                            <a href="#"><i class="fas fa-apple-alt me-2"></i>Oranges</a>
                                            <span>(5)</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="d-flex justify-content-between fruite-name">
                                            <a href="#"><i class="fas fa-apple-alt me-2"></i>Strawbery</a>
                                            <span>(2)</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="d-flex justify-content-between fruite-name">
                                            <a href="#"><i class="fas fa-apple-alt me-2"></i>Banana</a>
                                            <span>(8)</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="d-flex justify-content-between fruite-name">
                                            <a href="#"><i class="fas fa-apple-alt me-2"></i>Pumpkin</a>
                                            <span>(5)</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <!-- Featured Products -->
                        <div class="col-lg-12">
                            <h4 class="mb-4">Featured products</h4>
                            <?php $__empty_1 = true; $__currentLoopData = $featured_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="d-flex align-items-center justify-content-start">
                                    <div class="rounded" style="width: 100px; height: 100px;">
                                        <?php if($product->hasMedia('product_image')): ?>
                                            <img src="<?php echo e($product->getFirstMediaUrl('product_image', 'thumbnail')); ?>"
                                                class="img-fluid rounded" alt="Image">
                                        <?php else: ?>
                                            <img src="https://picsum.photos/130/<?php echo e($product->id + 100); ?>"
                                                class="img-fluid rounded" alt="Image">
                                        <?php endif; ?>

                                    </div>
                                    <div>
                                        <a href="<?php echo e(route('frontend.products.index', $product)); ?>">
                                            <h6 class="mb-2"><?php echo e($product->name); ?></h6>
                                        </a>
                                        <div class="d-flex mb-2">
                                            <i class="fa fa-star text-secondary"></i>
                                            <i class="fa fa-star text-secondary"></i>
                                            <i class="fa fa-star text-secondary"></i>
                                            <i class="fa fa-star text-secondary"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="d-flex mb-2">
                                            <h5 class="fw-bold me-2"><?php echo e((int) $product->offer_price); ?>৳</h5>
                                            <h5 class="text-danger text-decoration-line-through">
                                                <?php echo e((int) $product->base_price); ?>৳</h5>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php if (isset($component)) { $__componentOriginalc16dbe39dee1dac23ab3d25c192057d7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc16dbe39dee1dac23ab3d25c192057d7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.no-data','data' => ['text' => 'No products found...']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.no-data'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => 'No products found...']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc16dbe39dee1dac23ab3d25c192057d7)): ?>
<?php $attributes = $__attributesOriginalc16dbe39dee1dac23ab3d25c192057d7; ?>
<?php unset($__attributesOriginalc16dbe39dee1dac23ab3d25c192057d7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc16dbe39dee1dac23ab3d25c192057d7)): ?>
<?php $component = $__componentOriginalc16dbe39dee1dac23ab3d25c192057d7; ?>
<?php unset($__componentOriginalc16dbe39dee1dac23ab3d25c192057d7); ?>
<?php endif; ?>
                            <?php endif; ?>

                        </div>

                    </div>
                </div>
            </div>
            <!-- Related Products -->
            <h1 class="fw-bold mb-0">Related products</h1>
            <div class="vesitable">
                <div class="owl-carousel vegetable-carousel justify-content-center">
                    <?php $__empty_1 = true; $__currentLoopData = $related_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if (isset($component)) { $__componentOriginalc9c0614aab5883edf1ee17d99ceaf21b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc9c0614aab5883edf1ee17d99ceaf21b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.products.card-carousel','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.products.card-carousel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc9c0614aab5883edf1ee17d99ceaf21b)): ?>
<?php $attributes = $__attributesOriginalc9c0614aab5883edf1ee17d99ceaf21b; ?>
<?php unset($__attributesOriginalc9c0614aab5883edf1ee17d99ceaf21b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc9c0614aab5883edf1ee17d99ceaf21b)): ?>
<?php $component = $__componentOriginalc9c0614aab5883edf1ee17d99ceaf21b; ?>
<?php unset($__componentOriginalc9c0614aab5883edf1ee17d99ceaf21b); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php if (isset($component)) { $__componentOriginalc16dbe39dee1dac23ab3d25c192057d7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc16dbe39dee1dac23ab3d25c192057d7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.no-data','data' => ['text' => 'No products found...']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.no-data'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => 'No products found...']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc16dbe39dee1dac23ab3d25c192057d7)): ?>
<?php $attributes = $__attributesOriginalc16dbe39dee1dac23ab3d25c192057d7; ?>
<?php unset($__attributesOriginalc16dbe39dee1dac23ab3d25c192057d7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc16dbe39dee1dac23ab3d25c192057d7)): ?>
<?php $component = $__componentOriginalc16dbe39dee1dac23ab3d25c192057d7; ?>
<?php unset($__componentOriginalc16dbe39dee1dac23ab3d25c192057d7); ?>
<?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Single Product End -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views\frontend\products\show.blade.php ENDPATH**/ ?>