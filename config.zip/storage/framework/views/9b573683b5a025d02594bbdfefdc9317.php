<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['product']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['product']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="col-md-6 col-lg-6 col-xl-3">
    <div class="text-center">

        <a href="<?php echo e(route('frontend.products.show', $product)); ?>">
        <img src="<?php echo e(productImage($product)); ?>" class="img-fluid rounded" alt="<?php echo e($product->name); ?>">
        </a>

        <div class="py-4">
            <a href="<?php echo e(route('frontend.products.show', $product)); ?>" class="h5"><?php echo e($product->name); ?></a>
            <div class="d-flex my-3 justify-content-center">
                <i class="fas fa-star text-primary"></i>
                <i class="fas fa-star text-primary"></i>
                <i class="fas fa-star text-primary"></i>
                <i class="fas fa-star text-primary"></i>
                <i class="fas fa-star"></i>
            </div>
            <h4 class="mb-3"><?php echo e($product->base_price); ?> $</h4>
            <?php if (isset($component)) { $__componentOriginal304a67fe19a5cff26234eb3d57b66438 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal304a67fe19a5cff26234eb3d57b66438 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.buttons.add-to-card','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.buttons.add-to-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal304a67fe19a5cff26234eb3d57b66438)): ?>
<?php $attributes = $__attributesOriginal304a67fe19a5cff26234eb3d57b66438; ?>
<?php unset($__attributesOriginal304a67fe19a5cff26234eb3d57b66438); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal304a67fe19a5cff26234eb3d57b66438)): ?>
<?php $component = $__componentOriginal304a67fe19a5cff26234eb3d57b66438; ?>
<?php unset($__componentOriginal304a67fe19a5cff26234eb3d57b66438); ?>
<?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views\components\frontend\products\card-best-seller-secondary.blade.php ENDPATH**/ ?>