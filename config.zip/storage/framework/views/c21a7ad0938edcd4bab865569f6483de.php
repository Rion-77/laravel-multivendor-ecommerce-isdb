

<?php $__env->startSection('title', 'Vendors'); ?>

<?php $__env->startSection('content'); ?>
    <main class="app-main" id="main" tabindex="-1">

        <?php if (isset($component)) { $__componentOriginalf97de8cc237fb2376b7c7401879ba866 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf97de8cc237fb2376b7c7401879ba866 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.content-header','data' => ['title' => 'Vendor Profile']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.content-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Vendor Profile']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf97de8cc237fb2376b7c7401879ba866)): ?>
<?php $attributes = $__attributesOriginalf97de8cc237fb2376b7c7401879ba866; ?>
<?php unset($__attributesOriginalf97de8cc237fb2376b7c7401879ba866); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf97de8cc237fb2376b7c7401879ba866)): ?>
<?php $component = $__componentOriginalf97de8cc237fb2376b7c7401879ba866; ?>
<?php unset($__componentOriginalf97de8cc237fb2376b7c7401879ba866); ?>
<?php endif; ?>

        <div class="app-content">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-lg-4">
                        <div class="card card-primary card-outline">
                            <div class="card-body text-center">
                                <?php if($vendor->hasMedia('shop_logo')): ?>
                                    <img src="<?php echo e($vendor->getFirstMediaUrl('shop_logo', 'logo')); ?>"
                                        class="rounded-circle shadow" style="width:100px;height:100px;object-fit:cover;">
                                <?php else: ?>
                                    <img src="https://picsum.photos/300/<?php echo e($vendor->id + 300); ?>" alt=""
                                        class="rounded-circle shadow" style="width:100px;height:100px;object-fit:cover;">
                                <?php endif; ?>

                                <h3 class="mt-3 mb-0"><?php echo e($vendor->shop_name); ?></h3>
                                
                                <span class="badge text-bg-success mb-3"><i class="bi bi-patch-check-fill me-1"></i>Verified
                                    Vendor</span>
                                <div class="d-flex justify-content-center gap-2">
                                    <a href="<?php echo e(route('admin.vendors.edit', ['vendor' => $vendor->id])); ?>"
                                        class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil me-1"></i>Edit</a>

                                </div>
                            </div>
                            
                        </div>

                        
                        
                    </div>

                    <div class="col-lg-8">
                        

                        <div class="card">
                            <div class="card-header p-0 border-bottom-0">
                                <ul class="nav nav-tabs" id="vendor-tabs" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="tab-products-btn" data-bs-toggle="tab"
                                            data-bs-target="#tab-products" type="button" role="tab"
                                            aria-selected="true">Products</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="tab-orders-btn" data-bs-toggle="tab"
                                            data-bs-target="#tab-orders" type="button" role="tab" aria-selected="false"
                                            tabindex="-1">Recent Orders</button>
                                    </li>
                                    
                                </ul>
                            </div>
                            <div class="card-body">
                                <div class="tab-content">
                                    <div class="tab-pane fade show active" id="tab-products" role="tabpanel"
                                        aria-labelledby="tab-products-btn">
                                        <div class="row g-3">
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-6 col-md-4">
                                                    <div class="card h-100">
                                                        <?php if($product->hasMedia('product_image')): ?>
                                                            <img src="<?php echo e($product->getFirstMediaUrl('product_image', 'thumbnail')); ?>"
                                                                class="card-img-top" style="height:120px;object-fit:cover;">
                                                        <?php else: ?>
                                                            <img src="https://picsum.photos/300/<?php echo e($product->id + 300); ?>"
                                                                    class="card-img-top" style="height:120px;object-fit:cover;">
                                                            
                                                        <?php endif; ?>

                                                        <div class="card-body p-2">
                                                            <div class="fs-7 fw-medium text-truncate"><?php echo e($product->name); ?>

                                                            </div>
                                                            <div class="text-secondary fs-7">Price:
                                                                $<?php echo e(number_format($product->base_price)); ?></div>
                                                            <div class="text-secondary fs-7">Offer Price:
                                                                $<?php echo e(number_format($product->offer_price)); ?></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        
                                    </div>

                                    <div class="tab-pane fade" id="tab-orders" role="tabpanel"
                                        aria-labelledby="tab-orders-btn">
                                        <div class="table-responsive">
                                            <table class="table table-sm table-hover align-middle" role="table">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">Order</th>
                                                        <th scope="col">Customer</th>
                                                        <th scope="col">Amount</th>
                                                        <th scope="col">Status</th>
                                                        <th scope="col">Date</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>#ORD-10234</td>
                                                        <td>Michael Reyes</td>
                                                        <td>$149.00</td>
                                                        <td><span class="badge text-bg-success">Delivered</span></td>
                                                        <td>Sep 02, 2026</td>
                                                    </tr>
                                                    <tr>
                                                        <td>#ORD-10229</td>
                                                        <td>Sara Ahmed</td>
                                                        <td>$79.00</td>
                                                        <td><span class="badge text-bg-info">Shipped</span></td>
                                                        <td>Sep 01, 2026</td>
                                                    </tr>
                                                    <tr>
                                                        <td>#ORD-10218</td>
                                                        <td>Daniel Kim</td>
                                                        <td>$219.00</td>
                                                        <td><span class="badge text-bg-warning">Processing</span></td>
                                                        <td>Aug 30, 2026</td>
                                                    </tr>
                                                    <tr>
                                                        <td>#ORD-10201</td>
                                                        <td>Lena Fischer</td>
                                                        <td>$95.00</td>
                                                        <td><span class="badge text-bg-danger">Cancelled</span></td>
                                                        <td>Aug 28, 2026</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <a href="./orders-list.html" class="btn btn-sm btn-outline-secondary">View all
                                            orders</a>
                                    </div>

                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views\admin\vendors\show.blade.php ENDPATH**/ ?>