

<?php $__env->startSection('title', 'Product Categories'); ?>

<?php $__env->startSection('content'); ?>
    <main class="app-main" id="main" tabindex="-1">

        <?php if (isset($component)) { $__componentOriginalf97de8cc237fb2376b7c7401879ba866 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf97de8cc237fb2376b7c7401879ba866 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.content-header','data' => ['title' => 'Product Brands']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.content-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Product Brands']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf97de8cc237fb2376b7c7401879ba866)): ?>
<?php $attributes = $__attributesOriginalf97de8cc237fb2376b7c7401879ba866; ?>
<?php unset($__attributesOriginalf97de8cc237fb2376b7c7401879ba866); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf97de8cc237fb2376b7c7401879ba866)): ?>
<?php $component = $__componentOriginalf97de8cc237fb2376b7c7401879ba866; ?>
<?php unset($__componentOriginalf97de8cc237fb2376b7c7401879ba866); ?>
<?php endif; ?>

        <div class="app-content">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-lg-4">
                        <div class="card card-primary card-outline">
                            <div class="card-header">
                                <h3 class="card-title">Add Brand</h3>
                            </div>
                            <div class="card-body">
                                <form>
                                    <div class="mb-3">
                                        <label class="form-label" for="c-name">Brand name</label>
                                        <input type="text" class="form-control" id="c-name"
                                            placeholder="e.g. Home Appliances">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" for="c-parent">Parent Brand</label>
                                        <select class="form-select" id="c-parent">
                                            <option selected="">None (top-level)</option>
                                            <option>Electronics</option>
                                            <option>Fashion &amp; Apparel</option>
                                            <option>Home &amp; Living</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" for="c-desc">Description</label>
                                        <textarea class="form-control" id="c-desc" rows="3" placeholder="Optional short description"></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" for="c-icon">Icon</label>
                                        <input type="text" class="form-control" id="c-icon"
                                            placeholder="bi-tv (Bootstrap Icon class)">
                                    </div>
                                    <button type="submit" class="btn btn-primary w-100"><i
                                            class="bi bi-plus-lg me-1"></i>Add Brand</button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">All Brands</h3>
                                <div class="card-tools">
                                    <div class="input-group input-group-sm" style="width: 200px;">
                                        <input type="search" class="form-control" placeholder="Search brands…"
                                            aria-label="Search brands">
                                        <button class="btn btn-outline-secondary" type="button"><i
                                                class="bi bi-search"></i></button>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle m-0" role="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">Brand</th>
                                                
                                                <th scope="col">Products</th>
                                                
                                                <th class="text-end" scope="col">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <div class="d-flex align-items-center">
                                                            <i class="bi bi-tag fs-5 text-primary me-2"></i>
                                                            <span class="fw-medium"><?php echo e($brand->name); ?></span>
                                                        </div>
                                                    </td>
                                                    
                                                    <td><?php echo e($brand->products_count); ?></td>
                                                    
                                                    <td class="text-end">
                                                        <div class="btn-group btn-group-sm">
                                                            <button type="button" class="btn btn-outline-secondary"
                                                                aria-label="Edit Electronics"><i
                                                                    class="bi bi-pencil"></i></button>
                                                            <button type="button" class="btn btn-outline-danger"
                                                                aria-label="Delete Electronics"><i
                                                                    class="bi bi-trash"></i></button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views\admin\brands\index.blade.php ENDPATH**/ ?>