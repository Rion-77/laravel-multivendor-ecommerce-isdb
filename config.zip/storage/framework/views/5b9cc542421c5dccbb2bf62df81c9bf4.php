<?php $__env->startSection('title', 'Product List'); ?>

<?php $__env->startSection('content'); ?>
    <main class="app-main">

        <?php if (isset($component)) { $__componentOriginalf97de8cc237fb2376b7c7401879ba866 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf97de8cc237fb2376b7c7401879ba866 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.content-header','data' => ['title' => 'Products']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.content-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Products']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf97de8cc237fb2376b7c7401879ba866)): ?>
<?php $attributes = $__attributesOriginalf97de8cc237fb2376b7c7401879ba866; ?>
<?php unset($__attributesOriginalf97de8cc237fb2376b7c7401879ba866); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf97de8cc237fb2376b7c7401879ba866)): ?>
<?php $component = $__componentOriginalf97de8cc237fb2376b7c7401879ba866; ?>
<?php unset($__componentOriginalf97de8cc237fb2376b7c7401879ba866); ?>
<?php endif; ?>

        <div class="app-content">
            <div class="container-fluid">
                <!-- Flash Message -->
                <?php if (isset($component)) { $__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.success-flash-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.success-flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4)): ?>
<?php $attributes = $__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4; ?>
<?php unset($__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4)): ?>
<?php $component = $__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4; ?>
<?php unset($__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4); ?>
<?php endif; ?>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">All Products</h3>
                                <div class="card-tools">
                                    <div class="d-flex gap-2">
                                        <div class="input-group input-group-sm" style="width: 220px;">
                                            <input type="search" class="form-control" placeholder="Search products…"
                                                aria-label="Search products" />
                                            <button class="btn btn-outline-secondary" type="button"><i
                                                    class="bi bi-search"></i></button>
                                        </div>
                                        <select class="form-select form-select-sm w-auto" aria-label="Filter by vendor">
                                            <option selected>All vendors</option>
                                            <option>Nova Electronics</option>
                                            <option>Aarav Textiles Co.</option>
                                            <option>Urban Sole Footwear</option>
                                        </select>
                                        <select class="form-select form-select-sm w-auto" aria-label="Filter by status">
                                            <option selected>All statuses</option>
                                            <option>Published</option>
                                            <option>Draft</option>
                                            <option>Out of stock</option>
                                        </select>
                                        <!-- Add Button -->
                                        <?php if (isset($component)) { $__componentOriginale9eafe92fbc687d762c44a790b3da4a2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9eafe92fbc687d762c44a790b3da4a2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.buttons.add','data' => ['href' => ''.e(route('admin.products.create')).'','label' => 'Add Product']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.buttons.add'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.products.create')).'','label' => 'Add Product']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9eafe92fbc687d762c44a790b3da4a2)): ?>
<?php $attributes = $__attributesOriginale9eafe92fbc687d762c44a790b3da4a2; ?>
<?php unset($__attributesOriginale9eafe92fbc687d762c44a790b3da4a2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9eafe92fbc687d762c44a790b3da4a2)): ?>
<?php $component = $__componentOriginale9eafe92fbc687d762c44a790b3da4a2; ?>
<?php unset($__componentOriginale9eafe92fbc687d762c44a790b3da4a2); ?>
<?php endif; ?>

                                    </div>
                                </div>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle m-0">
                                        <thead>
                                            <tr>
                                                
                                                <th>Product</th>
                                                <th>Vendor</th>
                                                <th>Category</th>
                                                <th>Brand</th>
                                                <th>Price</th>
                                                
                                                <th>Status</th>
                                                <th class="text-end">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    
                                                    <td>
                                                        <div class="d-flex align-items-center">
                                                            <?php if($product->hasMedia('product_image')): ?>
                                                                <?php $__currentLoopData = $product->getMedia('product_image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <img src="<?php echo e($media->getUrl('thumbnail')); ?>"
                                                                        alt="" class="rounded me-2"
                                                                        style="width:40px;height:40px;object-fit:cover;" />
                                                                    
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php else: ?>
                                                                <img src="<?php echo e(asset('img/prod-1.jpg')); ?>" alt=""
                                                                    class="rounded me-2"
                                                                    style="width:40px;height:40px;object-fit:cover;" />
                                                            <?php endif; ?>

                                                            <div>
                                                                <div class="fw-medium"><?php echo e($product->name); ?></div>
                                                                
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td><?php echo e($product->vendor->shop_name); ?></td>
                                                    <td><?php echo e($product->category->name); ?></td>
                                                    <td><?php echo e($product->brand->name); ?></td>
                                                    <td><?php echo e($product->base_price); ?></td>
                                                    
                                                    <td><span class="badge text-<?php echo e($product->status->color()); ?>"><?php echo e($product->status->label()); ?></span></td>
                                                    <td class="text-end">
                                                        <div class="btn-group btn-group-sm">
                                                            <?php if (isset($component)) { $__componentOriginal863031594a424c3623342fc19fe1b416 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal863031594a424c3623342fc19fe1b416 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.buttons.view','data' => ['href' => ''.e(route('admin.products.show', ['product' => $product->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.buttons.view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.products.show', ['product' => $product->id])).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal863031594a424c3623342fc19fe1b416)): ?>
<?php $attributes = $__attributesOriginal863031594a424c3623342fc19fe1b416; ?>
<?php unset($__attributesOriginal863031594a424c3623342fc19fe1b416); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal863031594a424c3623342fc19fe1b416)): ?>
<?php $component = $__componentOriginal863031594a424c3623342fc19fe1b416; ?>
<?php unset($__componentOriginal863031594a424c3623342fc19fe1b416); ?>
<?php endif; ?>        
                                                            <?php if (isset($component)) { $__componentOriginalabbb943b8f386df8f42c669eb147a61c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalabbb943b8f386df8f42c669eb147a61c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.buttons.edit','data' => ['href' => ''.e(route('admin.products.edit', ['product' => $product->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.buttons.edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.products.edit', ['product' => $product->id])).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalabbb943b8f386df8f42c669eb147a61c)): ?>
<?php $attributes = $__attributesOriginalabbb943b8f386df8f42c669eb147a61c; ?>
<?php unset($__attributesOriginalabbb943b8f386df8f42c669eb147a61c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalabbb943b8f386df8f42c669eb147a61c)): ?>
<?php $component = $__componentOriginalabbb943b8f386df8f42c669eb147a61c; ?>
<?php unset($__componentOriginalabbb943b8f386df8f42c669eb147a61c); ?>
<?php endif; ?>
                                                            <?php if (isset($component)) { $__componentOriginal12797b8b267c721ccc5c314912d01159 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal12797b8b267c721ccc5c314912d01159 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.buttons.delete','data' => ['itemName' => ''.e($product->name).'','itemDeleteUrl' => ''.e(route('admin.products.destroy', ['product' => $product->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.buttons.delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['item-name' => ''.e($product->name).'','item-delete-url' => ''.e(route('admin.products.destroy', ['product' => $product->id])).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal12797b8b267c721ccc5c314912d01159)): ?>
<?php $attributes = $__attributesOriginal12797b8b267c721ccc5c314912d01159; ?>
<?php unset($__attributesOriginal12797b8b267c721ccc5c314912d01159); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal12797b8b267c721ccc5c314912d01159)): ?>
<?php $component = $__componentOriginal12797b8b267c721ccc5c314912d01159; ?>
<?php unset($__componentOriginal12797b8b267c721ccc5c314912d01159); ?>
<?php endif; ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- Pagination -->
                            <?php if (isset($component)) { $__componentOriginal1f9437379ffbb940ff05ba93353d3cd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9437379ffbb940ff05ba93353d3cd5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.pagination','data' => ['for' => $products]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($products)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9437379ffbb940ff05ba93353d3cd5)): ?>
<?php $attributes = $__attributesOriginal1f9437379ffbb940ff05ba93353d3cd5; ?>
<?php unset($__attributesOriginal1f9437379ffbb940ff05ba93353d3cd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9437379ffbb940ff05ba93353d3cd5)): ?>
<?php $component = $__componentOriginal1f9437379ffbb940ff05ba93353d3cd5; ?>
<?php unset($__componentOriginal1f9437379ffbb940ff05ba93353d3cd5); ?>
<?php endif; ?>

                        </div>
                    </div>
                </div>

                <!-- Delete Modal -->
                <?php if (isset($component)) { $__componentOriginalaa3b824e4662c5ae30529397669d1c1d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa3b824e4662c5ae30529397669d1c1d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.delete-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.delete-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa3b824e4662c5ae30529397669d1c1d)): ?>
<?php $attributes = $__attributesOriginalaa3b824e4662c5ae30529397669d1c1d; ?>
<?php unset($__attributesOriginalaa3b824e4662c5ae30529397669d1c1d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa3b824e4662c5ae30529397669d1c1d)): ?>
<?php $component = $__componentOriginalaa3b824e4662c5ae30529397669d1c1d; ?>
<?php unset($__componentOriginalaa3b824e4662c5ae30529397669d1c1d); ?>
<?php endif; ?>
                
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views\admin\products\index.blade.php ENDPATH**/ ?>