<p class="text-danger">
    <?php $__errorArgs = ["{$name}"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <?php echo e($message); ?>

    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</p>
<?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views/components/admin/error-message.blade.php ENDPATH**/ ?>