<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['product', 'class' => 'col-md-6 col-lg-4 col-xl-3']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['product', 'class' => 'col-md-6 col-lg-4 col-xl-3']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="<?php echo e($class); ?>">
    <div class="rounded position-relative fruite-item border border-secondary overflow-hidden">
        <a href="<?php echo e(route('frontend.products.show', $product)); ?>" class="fruite-img d-block">  
                <img src="<?php echo e(productImage($product)); ?>"
                    class="img-fluid w-100 rounded-top" alt=""> 
        </a>
        <div class="text-white bg-secondary px-3 py-1 rounded position-absolute" style="top: 10px; left: 10px;">
            <?php echo e($product->category->name); ?></div>
        <div class="p-4 rounded-bottom">
            <a href="<?php echo e(route('frontend.products.show', $product)); ?>">
                <h4 class="product-name"><?php echo e($product->name); ?></h4>
            </a>
            <div class="sold-by"><i class="fas fa-store me-1"></i>Sold by <a
                    href="<?php echo e(route('frontend.vendors.show', $product->vendor->id)); ?>"><?php echo e($product->vendor->shop_name); ?></a>
            </div>
            <p><?php echo e($product->description); ?></p>
            <div class="d-flex justify-content-between flex-lg-wrap">
                <p class="text-dark fs-5 fw-bold mb-0">
                    <?php echo e((int) $product->base_price); ?>tk</p>
                <?php if (isset($component)) { $__componentOriginal304a67fe19a5cff26234eb3d57b66438 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal304a67fe19a5cff26234eb3d57b66438 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.buttons.add-to-card','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.buttons.add-to-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal304a67fe19a5cff26234eb3d57b66438)): ?>
<?php $attributes = $__attributesOriginal304a67fe19a5cff26234eb3d57b66438; ?>
<?php unset($__attributesOriginal304a67fe19a5cff26234eb3d57b66438); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal304a67fe19a5cff26234eb3d57b66438)): ?>
<?php $component = $__componentOriginal304a67fe19a5cff26234eb3d57b66438; ?>
<?php unset($__componentOriginal304a67fe19a5cff26234eb3d57b66438); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views\components\frontend\products\card.blade.php ENDPATH**/ ?>