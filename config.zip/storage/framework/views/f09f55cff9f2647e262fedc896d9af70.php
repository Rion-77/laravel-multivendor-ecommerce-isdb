<!doctype html>
<html lang="en">
<!--begin::Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!--begin::Theme Init (prevents flash of incorrect theme on load, #6043)-->
    
    <!--end::Theme Init-->

    


    <!--begin::Fonts-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
        integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
        onload="this.media = 'all'" />
    <!--end::Fonts-->

    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Third Party Plugin(Bootstrap Icons)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(Bootstrap Icons)-->

    <!--begin::Required Plugin(AdminLTE)-->
    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/adminlte.css']); ?>
    <!--end::Required Plugin(AdminLTE)-->
    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body class="login-page bg-body-secondary app-loaded">
    <!--begin::App Wrapper-->

    <!--App Main-->
    <?php echo $__env->yieldContent('content'); ?>
    <!--end::App Main-->

    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/adminlte.js']); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views\admin\layouts\guest.blade.php ENDPATH**/ ?>