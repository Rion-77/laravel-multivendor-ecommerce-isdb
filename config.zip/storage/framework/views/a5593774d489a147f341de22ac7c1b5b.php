<?php
    $order_status_badges = [
        '1' => 'text-bg-warning',
        '2' => 'text-bg-primary',
        '3' => 'text-bg-info',
        '4' => 'text-bg-secondary',
        '5' => 'text-bg-success',
        '6' => 'text-bg-danger',
        '7' => 'text-bg-warning',
        '8' => 'text-bg-dark',
    ];
?>



<?php $__env->startSection('title', 'Vendors'); ?>

<?php $__env->startSection('content'); ?>
    <main class="app-main" id="main" tabindex="-1">

        <?php if (isset($component)) { $__componentOriginalf97de8cc237fb2376b7c7401879ba866 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf97de8cc237fb2376b7c7401879ba866 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.content-header','data' => ['title' => ''.e('#ORD-' . $order->order_number).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.content-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e('#ORD-' . $order->order_number).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf97de8cc237fb2376b7c7401879ba866)): ?>
<?php $attributes = $__attributesOriginalf97de8cc237fb2376b7c7401879ba866; ?>
<?php unset($__attributesOriginalf97de8cc237fb2376b7c7401879ba866); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf97de8cc237fb2376b7c7401879ba866)): ?>
<?php $component = $__componentOriginalf97de8cc237fb2376b7c7401879ba866; ?>
<?php unset($__componentOriginalf97de8cc237fb2376b7c7401879ba866); ?>
<?php endif; ?>


        <div class="app-content">
            <div class="container-fluid">

                <!-- Action bar (hidden on print) -->
                <div class="d-flex justify-content-end gap-2 mb-3 d-print-none">
                    <button class="btn btn-outline-secondary" onclick="window.print()" type="button">
                        <i class="bi bi-printer me-1" aria-hidden="true"></i>Print
                    </button>
                    <a href="#" class="btn btn-outline-secondary">
                        <i class="bi bi-download me-1" aria-hidden="true"></i>PDF
                    </a>
                    <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-primary">
                        <i class="bi bi-arrow-left" aria-hidden="true"></i>Back to all orders
                    </a>
                </div>

                <div class="row">
                    <!-- Printable order card -->
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-body p-4 p-md-5">

                                <!-- Header -->
                                <div class="row mb-4">
                                    
                                    <div class="col-sm-6 text-sm-start">
                                        <h1 class="h2 mb-1">Order</h1>
                                        <p class="text-secondary mb-0">
                                            <span class="fw-semibold">#</span>ORD-<?php echo e($order->order_number); ?>

                                        </p>
                                        <span
                                            class="badge <?php echo e($order_status_badges[$order->orderStatus->id] ?? 'text-bg-secondary'); ?> mt-1"><?php echo e($order->orderStatus->name); ?></span>
                                    </div>
                                </div>

                                <!-- Customer / shipping / order info -->
                                <div class="row mb-4">
                                    <div class="col-sm-4">
                                        <p class="text-secondary small mb-1">Customer</p>
                                        <p class="mb-0 fw-semibold"><?php echo e($order->shipping_recipient_name); ?></p>
                                        <p class="text-secondary small mb-0">
                                            <?php echo e($order->guest_email); ?><br>
                                            <?php echo e($order->shipping_phone); ?>

                                        </p>
                                    </div>
                                    <div class="col-sm-4">
                                        <p class="text-secondary small mb-1">Shipping address</p>
                                        <p class="mb-0 fw-semibold"><?php echo e($order->shipping_district); ?></p>
                                        <p class="text-secondary small mb-0"><?php echo e($order->shipping_address_line); ?></p>
                                    </div>
                                    <div class="col-sm-4 text-sm-end">
                                        <p class="text-secondary small mb-1">Order info</p>
                                        <p class="mb-0">Placed: <?php echo e($order->created_at->format('M d, Y')); ?></p>
                                        
                                        <p class="mb-0">Method: Cash On Delivery</p>
                                    </div>
                                </div>

                                <!-- Items -->
                                <div class="table-responsive mb-3">
                                    <table class="table align-middle mb-0" role="table">
                                        <thead>
                                            <tr>
                                                <th class="border-top-0" scope="col">Product</th>
                                                <th class="border-top-0 text-end" style="width: 6rem" scope="col">Qty
                                                </th>
                                                <th class="border-top-0 text-end" style="width: 9rem" scope="col">Unit
                                                    price</th>
                                                <th class="border-top-0 text-end" style="width: 9rem" scope="col">Amount
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <div class="d-flex align-items-center">
                                                            <img src="<?php echo e($order_item->product->hasMedia('product_image') ? $order_item->product->getFirstMediaUrl('product_image', 'thumbnail') : 'https://placehold.co/400'); ?>"
                                                                alt="" class="rounded me-2 d-print-none"
                                                                style="width:40px;height:40px;object-fit:cover;">
                                                            <p class="mb-0 fw-semibold"><?php echo e($order_item->product->name); ?>

                                                            </p>
                                                        </div>
                                                    </td>
                                                    <td class="text-end"><?php echo e($order_item->quantity); ?></td>
                                                    <td class="text-end"><?php echo e($order_item->unit_price); ?>৳</td>
                                                    <td class="text-end">
                                                        <?php echo e($order_item->quantity * $order_item->unit_price); ?>৳</td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>

                                <!-- Totals -->
                                <div class="row justify-content-end">
                                    <div class="col-md-5 col-lg-4">
                                        <dl class="row mb-0">
                                            <dt class="col-7 text-secondary fw-normal">Subtotal</dt>
                                            <dd class="col-5 text-end mb-2"><?php echo e($order->subtotal_amount); ?>৳</dd>
                                            <dt class="col-7 text-secondary fw-normal">Shipping</dt>
                                            <dd class="col-5 text-end mb-2"><?php echo e($order->shipping_fee); ?>৳</dd>

                                            <dt class="col-7 fw-semibold border-top pt-2">Total</dt>
                                            <dd class="col-5 text-end fw-semibold border-top pt-2 mb-0">
                                                <?php echo e($order->total_amount); ?>৳</dd>
                                        </dl>
                                    </div>
                                </div>

                                <!-- Timeline (kept visible on print as order history) -->
                                

                                <!-- Footer note -->
                                <hr class="my-4">
                                <p class="text-secondary small mb-0">
                                    Thanks for your business. If you have any questions about this order, please contact
                                    <a href="mailto:billing@example.com">billing@example.com</a>.
                                </p>

                            </div>
                        </div>
                    </div>

                    <!-- Sidebar controls (hidden on print) -->
                    <div class="col-lg-4 d-print-none">
                        <div class="card card-outline card-primary mb-3">
                            <div class="card-header">
                                <h3 class="card-title">Order Status</h3>
                            </div>
                            <div class="card-body">
                                <!-- Flash Message -->
                                <?php if (isset($component)) { $__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.success-flash-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.success-flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4)): ?>
<?php $attributes = $__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4; ?>
<?php unset($__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4)): ?>
<?php $component = $__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4; ?>
<?php unset($__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4); ?>
<?php endif; ?>
                                <form action="<?php echo e(route('admin.orders.update', $order->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    <select class="form-select mb-3" aria-label="Update order status"
                                        name="order_status_id">
                                        <?php $__currentLoopData = $order_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($order_status->id); ?>" <?php if($order->order_status_id == $order_status->id): echo 'selected'; endif; ?>>
                                                <?php echo e($order_status->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button type="submit" class="btn btn-primary w-100 mb-2"><i
                                            class="bi bi-check-lg me-1"></i>Update Status</button>
                                </form>

                                
                                
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views\admin\orders\show.blade.php ENDPATH**/ ?>