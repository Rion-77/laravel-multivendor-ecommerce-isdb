<?php
    $status_colors = [
        'active' => 'text-bg-success',
        'inactive' => 'text-bg-secondary',
        'suspended' => 'text-bg-danger',
        'pending' => 'text-bg-warning',
        'rejected' => 'text-bg-info',
    ];
    //    'text-bg-primary',
    // dd($status_colors['active'])
?>



<?php $__env->startSection('title', 'Vendors'); ?>

<?php $__env->startSection('content'); ?>
    <main class="app-main" id="main" tabindex="-1">

        <?php if (isset($component)) { $__componentOriginalf97de8cc237fb2376b7c7401879ba866 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf97de8cc237fb2376b7c7401879ba866 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.content-header','data' => ['title' => 'Vendors']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.content-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Vendors']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf97de8cc237fb2376b7c7401879ba866)): ?>
<?php $attributes = $__attributesOriginalf97de8cc237fb2376b7c7401879ba866; ?>
<?php unset($__attributesOriginalf97de8cc237fb2376b7c7401879ba866); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf97de8cc237fb2376b7c7401879ba866)): ?>
<?php $component = $__componentOriginalf97de8cc237fb2376b7c7401879ba866; ?>
<?php unset($__componentOriginalf97de8cc237fb2376b7c7401879ba866); ?>
<?php endif; ?>

        <div class="app-content">
            <div class="container-fluid">
                <!-- Flash Message -->
                <?php if (isset($component)) { $__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.success-flash-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.success-flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4)): ?>
<?php $attributes = $__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4; ?>
<?php unset($__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4)): ?>
<?php $component = $__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4; ?>
<?php unset($__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4); ?>
<?php endif; ?>

                <div class="row">
                    <div class="col-12">
                        <div class="row mb-3 g-3">
                            <div class="col-sm-6 col-lg-3">
                                <div class="card">
                                    <div class="card-body d-flex align-items-center">
                                        <div class="fs-2 text-primary me-3"><i class="bi bi-shop"></i></div>
                                        <div>
                                            <div class="fs-4 fw-semibold">248</div>
                                            <div class="text-secondary fs-7">Total Vendors</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <div class="card">
                                    <div class="card-body d-flex align-items-center">
                                        <div class="fs-2 text-success me-3"><i class="bi bi-check-circle"></i></div>
                                        <div>
                                            <div class="fs-4 fw-semibold">211</div>
                                            <div class="text-secondary fs-7">Approved</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <div class="card">
                                    <div class="card-body d-flex align-items-center">
                                        <div class="fs-2 text-warning me-3"><i class="bi bi-hourglass-split"></i></div>
                                        <div>
                                            <div class="fs-4 fw-semibold">27</div>
                                            <div class="text-secondary fs-7">Pending Approval</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <div class="card">
                                    <div class="card-body d-flex align-items-center">
                                        <div class="fs-2 text-danger me-3"><i class="bi bi-slash-circle"></i></div>
                                        <div>
                                            <div class="fs-4 fw-semibold">10</div>
                                            <div class="text-secondary fs-7">Suspended</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">All Vendors</h3>
                                <div class="card-tools">
                                    <div class="d-flex gap-2">
                                        <div class="input-group input-group-sm" style="width: 220px;">
                                            <input type="search" class="form-control" placeholder="Search vendors…"
                                                aria-label="Search vendors">
                                            <button class="btn btn-outline-secondary" type="button"><i
                                                    class="bi bi-search"></i></button>
                                        </div>
                                        <select class="form-select form-select-sm w-auto" aria-label="Filter by status">
                                            <option value="all" selected="">All statuses</option>
                                            <option value="approved">Approved</option>
                                            <option value="pending">Pending</option>
                                            <option value="suspended">Suspended</option>
                                        </select>
                                        <a href="<?php echo e(route('admin.vendors.create')); ?>" class="btn btn-sm btn-primary">
                                            <i class="bi bi-plus-lg me-1"></i>Add Vendor
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle m-0" role="table">
                                        <thead>
                                            <tr>
                                               
                                                <th scope="col">Vendor</th>
                                                <th scope="col">Owner</th>
                                                
                                                <th scope="col">Products</th>
                                                
                                                
                                                
                                                <th scope="col">Status</th>
                                                <th class="text-end" scope="col">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <div class="d-flex align-items-center">
                                                            <?php if($vendor->hasMedia('shop_logo')): ?>
                                                                <img src="<?php echo e($vendor->getFirstMediaUrl('shop_logo', 'logo')); ?>"
                                                                    class="img-size-32 rounded-circle me-2">
                                                            <?php else: ?>
                                                                <img src="https://picsum.photos/300/<?php echo e($vendor->id + 300); ?>"
                                                                    alt="" class="img-size-32 rounded-circle me-2">
                                                            <?php endif; ?>
                                                            <div>
                                                                <div class="fw-medium"><?php echo e($vendor->shop_name); ?></div>
                                                                
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td><?php echo e($vendor->user->name); ?></td>
                                                    
                                                    <td><?php echo e(random_int(5, 20)); ?></td>
                                                    
                                                    
                                                    <td><span
                                                            class="badge <?php echo e($status_colors[$vendor->status->value]); ?> "><?php echo e($vendor->status->value); ?></span>
                                                    </td>
                                                    <td class="text-end">
                                                        <div class="btn-group btn-group-sm">
                                                            
                                                            <?php if (isset($component)) { $__componentOriginal863031594a424c3623342fc19fe1b416 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal863031594a424c3623342fc19fe1b416 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.buttons.view','data' => ['href' => ''.e(route('admin.vendors.show', ['vendor' => $vendor->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.buttons.view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.vendors.show', ['vendor' => $vendor->id])).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal863031594a424c3623342fc19fe1b416)): ?>
<?php $attributes = $__attributesOriginal863031594a424c3623342fc19fe1b416; ?>
<?php unset($__attributesOriginal863031594a424c3623342fc19fe1b416); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal863031594a424c3623342fc19fe1b416)): ?>
<?php $component = $__componentOriginal863031594a424c3623342fc19fe1b416; ?>
<?php unset($__componentOriginal863031594a424c3623342fc19fe1b416); ?>
<?php endif; ?>        
                                                            <?php if (isset($component)) { $__componentOriginalabbb943b8f386df8f42c669eb147a61c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalabbb943b8f386df8f42c669eb147a61c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.buttons.edit','data' => ['href' => ''.e(route('admin.vendors.edit', ['vendor' => $vendor->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.buttons.edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.vendors.edit', ['vendor' => $vendor->id])).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalabbb943b8f386df8f42c669eb147a61c)): ?>
<?php $attributes = $__attributesOriginalabbb943b8f386df8f42c669eb147a61c; ?>
<?php unset($__attributesOriginalabbb943b8f386df8f42c669eb147a61c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalabbb943b8f386df8f42c669eb147a61c)): ?>
<?php $component = $__componentOriginalabbb943b8f386df8f42c669eb147a61c; ?>
<?php unset($__componentOriginalabbb943b8f386df8f42c669eb147a61c); ?>
<?php endif; ?>
                                                            <?php if (isset($component)) { $__componentOriginal12797b8b267c721ccc5c314912d01159 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal12797b8b267c721ccc5c314912d01159 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.buttons.delete','data' => ['itemName' => ''.e($vendor->shop_name).'','itemDeleteUrl' => ''.e(route('admin.vendors.destroy', ['vendor' => $vendor->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.buttons.delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['item-name' => ''.e($vendor->shop_name).'','item-delete-url' => ''.e(route('admin.vendors.destroy', ['vendor' => $vendor->id])).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal12797b8b267c721ccc5c314912d01159)): ?>
<?php $attributes = $__attributesOriginal12797b8b267c721ccc5c314912d01159; ?>
<?php unset($__attributesOriginal12797b8b267c721ccc5c314912d01159); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal12797b8b267c721ccc5c314912d01159)): ?>
<?php $component = $__componentOriginal12797b8b267c721ccc5c314912d01159; ?>
<?php unset($__componentOriginal12797b8b267c721ccc5c314912d01159); ?>
<?php endif; ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <!-- Pagination -->
                            <?php if (isset($component)) { $__componentOriginal1f9437379ffbb940ff05ba93353d3cd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9437379ffbb940ff05ba93353d3cd5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.pagination','data' => ['for' => $vendors]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($vendors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9437379ffbb940ff05ba93353d3cd5)): ?>
<?php $attributes = $__attributesOriginal1f9437379ffbb940ff05ba93353d3cd5; ?>
<?php unset($__attributesOriginal1f9437379ffbb940ff05ba93353d3cd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9437379ffbb940ff05ba93353d3cd5)): ?>
<?php $component = $__componentOriginal1f9437379ffbb940ff05ba93353d3cd5; ?>
<?php unset($__componentOriginal1f9437379ffbb940ff05ba93353d3cd5); ?>
<?php endif; ?>

                        </div>
                    </div>
                </div>
                <!-- Delete Modal -->
                <?php if (isset($component)) { $__componentOriginalaa3b824e4662c5ae30529397669d1c1d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa3b824e4662c5ae30529397669d1c1d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.delete-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.delete-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa3b824e4662c5ae30529397669d1c1d)): ?>
<?php $attributes = $__attributesOriginalaa3b824e4662c5ae30529397669d1c1d; ?>
<?php unset($__attributesOriginalaa3b824e4662c5ae30529397669d1c1d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa3b824e4662c5ae30529397669d1c1d)): ?>
<?php $component = $__componentOriginalaa3b824e4662c5ae30529397669d1c1d; ?>
<?php unset($__componentOriginalaa3b824e4662c5ae30529397669d1c1d); ?>
<?php endif; ?>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views\admin\vendors\index.blade.php ENDPATH**/ ?>