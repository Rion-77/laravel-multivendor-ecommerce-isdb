<?php $__env->startSection('content'); ?>
    <main class="login-box" id="main" tabindex="-1">
        <h1 class="login-logo">
            <a href="../index2.html">Multivendor Ecommerce</a>
        </h1>
        <!-- /.login-logo -->
        <div class="card">

            <div class="card-body login-card-body">
                <p class="login-box-msg">Sign in to start your session</p>

                <div class = "text-center">
                    <?php if (isset($component)) { $__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.error-message','data' => ['name' => 'email']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.error-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78)): ?>
<?php $attributes = $__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78; ?>
<?php unset($__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78)): ?>
<?php $component = $__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78; ?>
<?php unset($__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.error-message','data' => ['name' => 'password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.error-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78)): ?>
<?php $attributes = $__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78; ?>
<?php unset($__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78)): ?>
<?php $component = $__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78; ?>
<?php unset($__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78); ?>
<?php endif; ?>
                </div>

                <div class="my-3 d-flex gap-2 justify-content-center flex-wrap">
                    <button class="btn btn-primary email-change-btn" style="width: auto"type="button"
                        data-email="admin@example.com">
                        <span>Admin</span>
                    </button>
                    <button class="btn btn-primary email-change-btn" style="width: auto"type="button"
                        data-email="vendor@example.com">
                        <span>Vendor</span>
                    </button>
                </div>

                <form action="<?php echo e(route('admin.login')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <label class="visually-hidden" for="loginEmail">Email</label>
                    <div class="input-group mb-3">
                        <input id="loginEmail" type="email" name="email" class="form-control" placeholder="Email"
                            value="admin@example.com">
                        <div class="input-group-text">
                            <span class="bi bi-envelope"></span>
                        </div>
                    </div>
                    <label class="visually-hidden" for="loginPassword">Password</label>
                    <div class="input-group mb-3">
                        <input id="loginPassword" type="password" name="password" class="form-control"
                            placeholder="Password" value="password">
                        <div class="input-group-text">
                            <span class="bi bi-lock-fill"></span>
                        </div>
                    </div>
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-8">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                <label class="form-check-label" for="flexCheckDefault"> Remember Me </label>
                            </div>
                        </div>
                        <!-- /.col -->
                        <div class="col-4">
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">Sign In</button>
                            </div>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!--end::Row-->
                </form>

                <div class="social-auth-links text-center mb-3 d-grid gap-2">
                    <p>- OR -</p>
                    <a href="#" class="btn btn-primary">
                        <i class="bi bi-facebook me-2"></i> Sign in using Facebook
                    </a>
                    <a href="#" class="btn btn-danger">
                        <i class="bi bi-google me-2"></i> Sign in using Google
                    </a>
                </div>
                <!-- /.social-auth-links -->

                <p class="mb-1">
                    <a href="forgot-password.html">I forgot my password</a>
                </p>
                <p class="mb-0">
                    <a href="register.html" class="text-center"> Register a new membership </a>
                </p>
            </div>
            <!-- /.login-card-body -->
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
 <script>
        document.querySelectorAll('.email-change-btn').forEach(button => {
            button.addEventListener('click', () => {
                document.querySelector('#loginEmail').value = button.dataset.email;
            })
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views\admin\auth\login.blade.php ENDPATH**/ ?>