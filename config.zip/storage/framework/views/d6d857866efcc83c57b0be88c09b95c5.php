<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['label', 'type' => 'text', 'name', 'value' => null, 'placeholder' => null, 'class' => 'col-md-6']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['label', 'type' => 'text', 'name', 'value' => null, 'placeholder' => null, 'class' => 'col-md-6']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="<?php echo e($class); ?>">
    <label class="form-label" for="<?php echo e($name); ?>"><?php echo e($label); ?></label>
    <div class="input-group">
        <?php if($slot->hasActualContent()): ?>
            <span class="input-group-text"><?php echo e($slot); ?></span>
        <?php endif; ?>
        <input type="<?php echo e($type); ?>" class="form-control" id="<?php echo e($name); ?>" placeholder="<?php echo e($placeholder); ?>"
            name="<?php echo e($name); ?>" value="<?php echo e($value); ?>">
    </div>
    <?php if (isset($component)) { $__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.error-message','data' => ['name' => ''.e($name).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.error-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($name).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78)): ?>
<?php $attributes = $__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78; ?>
<?php unset($__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78)): ?>
<?php $component = $__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78; ?>
<?php unset($__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78); ?>
<?php endif; ?>
</div>
<?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views/components/admin/form/input.blade.php ENDPATH**/ ?>