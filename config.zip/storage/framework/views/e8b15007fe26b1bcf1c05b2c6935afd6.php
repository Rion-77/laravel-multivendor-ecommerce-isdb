<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['vendor', 'class' => 'col-md-6 col-lg-3']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['vendor', 'class' => 'col-md-6 col-lg-3']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="<?php echo e($class); ?>">
    <div class="vendor-card">

        <div class="text-center px-3 pb-4">
            <?php if($vendor->hasMedia('shop_logo')): ?>
                <img src="<?php echo e($vendor->getFirstMediaUrl('shop_logo', 'logo')); ?>" class="vendor-logo mb-2"
                    alt="<?php echo e($vendor->shop_name); ?>">
            <?php else: ?>
                <img src="https://picsum.photos/<?php echo e($vendor->id + 100); ?>/<?php echo e($vendor->id + 100); ?>" class="vendor-logo mb-2"
                    alt="<?php echo e($vendor->shop_name); ?>">
            <?php endif; ?>
            <h5 class="mb-0"><?php echo e($vendor->shop_name); ?><i class="fas fa-check-circle vendor-badge-verified"></i></h5>
            <div class="rating d-flex justify-content-center my-2">
                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i
                    class="fas fa-star"></i><i class="fas fa-star-half-alt"></i>
                <span class="rating-count">(4.5)</span>
            </div>
            <p class="vendor-stats mb-3"><?php echo e($vendor->products_count); ?> Products</p>
            <a href="<?php echo e(route('frontend.vendors.show', $vendor)); ?>" class="btn border border-secondary rounded-pill px-4 py-1 text-primary">Visit
                Store</a>
        </div>
    </div>
</div>
<?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views\components\frontend\vendor-card.blade.php ENDPATH**/ ?>