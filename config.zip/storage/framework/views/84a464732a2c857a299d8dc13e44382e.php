<?php
    $role_badge_colors = ['text-bg-danger', 'text-bg-primary', 'text-bg-info', 'text-bg-secondary'];
    // dd($role_badge_colors[0+1])
?>


<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content'); ?>



    <main class="app-main" id="main" tabindex="-1">
        <!--begin::App Content Header-->
        <?php if (isset($component)) { $__componentOriginalf97de8cc237fb2376b7c7401879ba866 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf97de8cc237fb2376b7c7401879ba866 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.content-header','data' => ['title' => 'Users']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.content-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Users']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf97de8cc237fb2376b7c7401879ba866)): ?>
<?php $attributes = $__attributesOriginalf97de8cc237fb2376b7c7401879ba866; ?>
<?php unset($__attributesOriginalf97de8cc237fb2376b7c7401879ba866); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf97de8cc237fb2376b7c7401879ba866)): ?>
<?php $component = $__componentOriginalf97de8cc237fb2376b7c7401879ba866; ?>
<?php unset($__componentOriginalf97de8cc237fb2376b7c7401879ba866); ?>
<?php endif; ?>
        <!--end::App Content Header-->



        <!--begin::App Content-->
        <div class="app-content">
            <!--begin::Container-->
            <div class="container-fluid">
                <!-- Flash Message -->
                <?php if (isset($component)) { $__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.success-flash-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.success-flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4)): ?>
<?php $attributes = $__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4; ?>
<?php unset($__attributesOriginal81aa5fa42f0b9882c7a90b0878d517c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4)): ?>
<?php $component = $__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4; ?>
<?php unset($__componentOriginal81aa5fa42f0b9882c7a90b0878d517c4); ?>
<?php endif; ?>

                <!--begin::Row-->
                <div class="row">
                    <div class="col-12">
                        <!--begin::Card-->
                        <div class="card mb-4">
                            <!--begin::Card Header-->
                            <div class="card-header">
                                <div class="row g-2 align-items-center">
                                    <div class="col-12 col-md-4">
                                        <h3 class="card-title">User Directory</h3>
                                    </div>
                                    <div class="col-12 col-md-8">
                                        <div class="d-flex flex-wrap justify-content-md-end gap-2">
                                            <div class="input-group input-group-sm w-auto">
                                                <span class="input-group-text">
                                                    <i class="bi bi-search" aria-hidden="true"></i>
                                                </span>
                                                <input type="search" id="user-search" class="form-control"
                                                    placeholder="Search users" aria-label="Search users"
                                                    style="width: 180px">
                                            </div>
                                            <select id="user-role-filter" class="form-select form-select-sm w-auto"
                                                aria-label="Filter by role">
                                                <option value="0" selected="">All roles</option>
                                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($role->id); ?>"
                                                        <?php if(isset($role_id)): ?> <?php if($role_id == $role->id): echo 'selected'; endif; ?> <?php endif; ?>>
                                                        <?php echo e($role->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <!-- Add Button -->
                                            <?php if (isset($component)) { $__componentOriginale9eafe92fbc687d762c44a790b3da4a2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9eafe92fbc687d762c44a790b3da4a2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.buttons.add','data' => ['href' => ''.e(route('admin.users.create')).'','label' => 'New user']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.buttons.add'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.users.create')).'','label' => 'New user']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9eafe92fbc687d762c44a790b3da4a2)): ?>
<?php $attributes = $__attributesOriginale9eafe92fbc687d762c44a790b3da4a2; ?>
<?php unset($__attributesOriginale9eafe92fbc687d762c44a790b3da4a2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9eafe92fbc687d762c44a790b3da4a2)): ?>
<?php $component = $__componentOriginale9eafe92fbc687d762c44a790b3da4a2; ?>
<?php unset($__componentOriginale9eafe92fbc687d762c44a790b3da4a2); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--end::Card Header-->
                            <!--begin::Card Body-->
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle m-0" role="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">User</th>
                                                <th scope="col">Email</th>
                                                <th scope="col">Phone</th>
                                                <th scope="col">Role</th>
                                                <th scope="col">Created</th>
                                                <th class="text-end" scope="col">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <div class="d-flex align-items-center">

                                                            <?php if($user->hasMedia('profile_image')): ?>
                                                                <img src="<?php echo e($user->getFirstMediaUrl('profile_image', 'avatar')); ?>"
                                                                    class="img-size-32 rounded-circle me-2">
                                                            <?php else: ?>
                                                                <img src="https://i.pravatar.cc/150?img=<?php echo e($user->id); ?>"
                                                                    alt="" class="img-size-32 rounded-circle me-2">
                                                            <?php endif; ?>
                                                            <span class="fw-medium"><?php echo e($user->name); ?></span>
                                                        </div>
                                                    </td>
                                                    <td><?php echo e($user->email); ?></td>
                                                    <td><?php echo e($user->phone); ?></td>
                                                    <td>
                                                        <span class="badge <?php echo e($role_badge_colors[$user->role_id - 1]); ?>">
                                                            <?php echo e($user->role->name); ?> </span>
                                                    </td>

                                                    <td><?php echo e($user->created_at); ?></td>
                                                    <td class="text-end">
                                                        <div class="btn-group btn-group-sm">
                                                            <?php if (isset($component)) { $__componentOriginalabbb943b8f386df8f42c669eb147a61c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalabbb943b8f386df8f42c669eb147a61c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.buttons.edit','data' => ['href' => ''.e(route('admin.users.edit', ['user' => $user->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.buttons.edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.users.edit', ['user' => $user->id])).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalabbb943b8f386df8f42c669eb147a61c)): ?>
<?php $attributes = $__attributesOriginalabbb943b8f386df8f42c669eb147a61c; ?>
<?php unset($__attributesOriginalabbb943b8f386df8f42c669eb147a61c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalabbb943b8f386df8f42c669eb147a61c)): ?>
<?php $component = $__componentOriginalabbb943b8f386df8f42c669eb147a61c; ?>
<?php unset($__componentOriginalabbb943b8f386df8f42c669eb147a61c); ?>
<?php endif; ?>
                                                            <?php if (isset($component)) { $__componentOriginal12797b8b267c721ccc5c314912d01159 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal12797b8b267c721ccc5c314912d01159 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.buttons.delete','data' => ['itemName' => ''.e($user->name).'','itemDeleteUrl' => ''.e(route('admin.users.destroy', ['user' => $user->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.buttons.delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['item-name' => ''.e($user->name).'','item-delete-url' => ''.e(route('admin.users.destroy', ['user' => $user->id])).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal12797b8b267c721ccc5c314912d01159)): ?>
<?php $attributes = $__attributesOriginal12797b8b267c721ccc5c314912d01159; ?>
<?php unset($__attributesOriginal12797b8b267c721ccc5c314912d01159); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal12797b8b267c721ccc5c314912d01159)): ?>
<?php $component = $__componentOriginal12797b8b267c721ccc5c314912d01159; ?>
<?php unset($__componentOriginal12797b8b267c721ccc5c314912d01159); ?>
<?php endif; ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.table-responsive -->
                            </div>
                            <!--end::Card Body-->
                            <!--begin::Card Footer-->
                            
                            <!-- Pagination -->
                            <?php if (isset($component)) { $__componentOriginal1f9437379ffbb940ff05ba93353d3cd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9437379ffbb940ff05ba93353d3cd5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.pagination','data' => ['for' => $users]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($users)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9437379ffbb940ff05ba93353d3cd5)): ?>
<?php $attributes = $__attributesOriginal1f9437379ffbb940ff05ba93353d3cd5; ?>
<?php unset($__attributesOriginal1f9437379ffbb940ff05ba93353d3cd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9437379ffbb940ff05ba93353d3cd5)): ?>
<?php $component = $__componentOriginal1f9437379ffbb940ff05ba93353d3cd5; ?>
<?php unset($__componentOriginal1f9437379ffbb940ff05ba93353d3cd5); ?>
<?php endif; ?>
                            
                            <!--end::Card Footer-->
                        </div>
                        <!--end::Card-->
                    </div>
                    <!-- /.col -->
                </div>
                <!--end::Row-->



                <!--begin::Delete User Modal-->
                <?php if (isset($component)) { $__componentOriginalaa3b824e4662c5ae30529397669d1c1d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa3b824e4662c5ae30529397669d1c1d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.delete-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.delete-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa3b824e4662c5ae30529397669d1c1d)): ?>
<?php $attributes = $__attributesOriginalaa3b824e4662c5ae30529397669d1c1d; ?>
<?php unset($__attributesOriginalaa3b824e4662c5ae30529397669d1c1d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa3b824e4662c5ae30529397669d1c1d)): ?>
<?php $component = $__componentOriginalaa3b824e4662c5ae30529397669d1c1d; ?>
<?php unset($__componentOriginalaa3b824e4662c5ae30529397669d1c1d); ?>
<?php endif; ?>
                <!--end::Delete User Modal-->
            </div>
            <!--end::Container-->
        </div>
        <!--end::App Content-->
    </main>

<?php $__env->stopSection(); ?>

<form method="POST" class="d-none role-change-form">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="role_id">
    <button type="submit">submit</button>
</form>


<?php $__env->startSection('scripts'); ?>
    <script>
        const roleSelector = document.querySelector('#user-role-filter');
        const roleChangeForm = document.querySelector('.role-change-form');
        console.log(roleSelector);
        roleSelector.addEventListener('change', () => {
            console.log(roleSelector.value);
            // const route = `<?php echo e(route('admin.users.index')); ?>`;
            const route = (`<?php echo e(route('admin.users.roleIndex', ['role' => 0])); ?>`.replace('0', roleSelector.value));
            roleChangeForm.action = route;
            console.log(roleChangeForm);
            roleChangeForm.submit();
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views\admin\users\index.blade.php ENDPATH**/ ?>