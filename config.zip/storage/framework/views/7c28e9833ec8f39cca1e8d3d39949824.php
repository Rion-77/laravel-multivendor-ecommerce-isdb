

    <!-- Spinner Start -->
    <div id="spinner"
        class="show w-100 vh-100 bg-white position-fixed translate-middle top-50 start-50  d-flex align-items-center justify-content-center">
        <div class="spinner-grow text-primary" role="status"></div>
    </div>
    <!-- Spinner End -->


    <!-- Navbar start -->
    <div class="container-fluid fixed-top">
        <div class="container topbar bg-primary d-none d-lg-block">
            <div class="d-flex justify-content-between">
                <div class="top-info ps-2">
                    <small class="me-3"><i class="fas fa-map-marker-alt me-2 text-secondary"></i> <a href="#"
                            class="text-white">123 Street, New York</a></small>
                    <small class="me-3"><i class="fas fa-envelope me-2 text-secondary"></i><a href="#"
                            class="text-white">Email@Example.com</a></small>
                </div>
                <div class="top-link pe-2">
                    <a href="become-vendor.html" class="text-white"><small class="text-white mx-2"><i
                                class="fas fa-store me-1"></i>Become a Vendor</small>/</a>
                    <a href="#" class="text-white"><small class="text-white mx-2">Privacy Policy</small>/</a>
                    <a href="#" class="text-white"><small class="text-white ms-2">Terms of Use</small></a>
                </div>
            </div>
        </div>
        <div class="container px-0">
            <nav class="navbar navbar-light bg-white navbar-expand-xl">
                <a href="<?php echo e(route('homepage')); ?>" class="navbar-brand d-flex align-items-end">
                    <h1 class="text-primary display-6 mb-0">ShopSphere</h1>
                    <span class="badge bg-secondary text-dark rounded-pill mb-2 ms-2 d-none d-sm-inline-block"
                        style="font-size: 11px;">MARKETPLACE</span>
                </a>
                <button class="navbar-toggler py-2 px-3" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarCollapse">
                    <span class="fa fa-bars text-primary"></span>
                </button>
                <div class="collapse navbar-collapse bg-white" id="navbarCollapse">
                    <div class="navbar-nav mx-auto">
                        <a href="<?php echo e(route('homepage')); ?>" class="nav-item nav-link <?php echo e(activeLink('homepage')); ?>">Home</a>
                        <a href="<?php echo e(route('frontend.products.index')); ?>" class="nav-item nav-link <?php echo e(activeLink('frontend.products*')); ?>">Shop</a>
                        <a href="<?php echo e(route('frontend.vendors.index')); ?>" class="nav-item nav-link <?php echo e(activeLink('frontend.vendors*')); ?>">Vendors</a>
                        
                        

                        <a href="<?php echo e(route('become-vendor')); ?>" class="nav-item nav-link <?php echo e(activeLink('become-vendor')); ?>">Become a Vendor</a>
                        <a href="<?php echo e(route('admin.products.index')); ?>" target="_blank" class="nav-item nav-link <?php echo e(activeLink('become-vendor')); ?>">Admin</a>
                        <a href="<?php echo e(route('contact-us')); ?>" class="nav-item nav-link <?php echo e(activeLink('c')); ?>">Contact</a>
                    </div>
                    <div class="d-flex m-3 me-0">
                        <button
                            class="btn-search btn border border-secondary btn-md-square rounded-circle bg-white me-3"
                            data-bs-toggle="modal" data-bs-target="#searchModal"><i
                                class="fas fa-search text-primary"></i></button>
                        
                        <!-- Cart -->
                        <a href="<?php echo e(route('cart')); ?>" class="position-relative me-3 my-auto">
                            <i class="fa fa-shopping-bag fa-2x"></i>
                            <span
                                class="position-absolute bg-secondary rounded-circle d-flex align-items-center justify-content-center text-dark px-1 cart-item-counter"
                                style="top: -5px; left: 15px; height: 20px; min-width: 20px;">3</span>
                        </a>
                        <div class="nav-item dropdown my-auto">
                            <a href="#" class="dropdown-toggle" data-bs-toggle="dropdown"
                                style="color: inherit;"><i class="fas fa-user fa-2x"></i></a>
                            <div class="dropdown-menu dropdown-menu-end m-0 bg-secondary rounded-0">
                                <a href="login.html" class="dropdown-item">Login</a>
                                <a href="register.html" class="dropdown-item">Register</a>
                                <a href="become-vendor.html" class="dropdown-item">Become a Vendor</a>
                                <a href="vendor-dashboard.html" class="dropdown-item">Vendor Dashboard</a>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
    </div>
    <!-- Navbar End -->


    <!-- Modal Search Start -->
    <div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-fullscreen">
            <div class="modal-content rounded-0">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Search by keyword</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body d-flex align-items-center">
                    <div class="input-group w-75 mx-auto d-flex">
                        <input type="search" class="form-control p-3" placeholder="keywords"
                            aria-describedby="search-icon-1">
                        <span id="search-icon-1" class="input-group-text p-3"><i class="fa fa-search"></i></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Search End --><?php /**PATH D:\Laravel\multivendor-ecommerce\resources\views\frontend\layouts\header.blade.php ENDPATH**/ ?>