@extends('admin.layouts.guest')

@section('content')
    <main class="login-box" id="main" tabindex="-1">
        <h1 class="login-logo">
            <a href="../index2.html">Multivendor Ecommerce</a>
        </h1>
        <!-- /.login-logo -->
        <div class="card">

            <div class="card-body login-card-body">
                <p class="login-box-msg">Sign in to start your session</p>

                <div class = "text-center">
                    <x-admin.error-message name="email" />
                    <x-admin.error-message name="password" />
                </div>

                <div class="my-3 d-flex gap-2 justify-content-center flex-wrap">
                    <button class="btn btn-primary email-change-btn" style="width: auto"type="button"
                        data-email="admin@example.com">
                        <span>Admin</span>
                    </button>
                    <button class="btn btn-primary email-change-btn" style="width: auto"type="button"
                        data-email="vendor@example.com">
                        <span>Vendor</span>
                    </button>
                </div>

                <form action="{{ route('admin.login') }}" method="post">
                    @csrf
                    <label class="visually-hidden" for="loginEmail">Email</label>
                    <div class="input-group mb-3">
                        <input id="loginEmail" type="email" name="email" class="form-control" placeholder="Email"
                            value="admin@example.com">
                        <div class="input-group-text">
                            <span class="bi bi-envelope"></span>
                        </div>
                    </div>
                    <label class="visually-hidden" for="loginPassword">Password</label>
                    <div class="input-group mb-3">
                        <input id="loginPassword" type="password" name="password" class="form-control"
                            placeholder="Password" value="password">
                        <div class="input-group-text">
                            <span class="bi bi-lock-fill"></span>
                        </div>
                    </div>
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-8">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                <label class="form-check-label" for="flexCheckDefault"> Remember Me </label>
                            </div>
                        </div>
                        <!-- /.col -->
                        <div class="col-4">
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">Sign In</button>
                            </div>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!--end::Row-->
                </form>

                <div class="social-auth-links text-center mb-3 d-grid gap-2">
                    <p>- OR -</p>
                    <a href="#" class="btn btn-primary">
                        <i class="bi bi-facebook me-2"></i> Sign in using Facebook
                    </a>
                    <a href="#" class="btn btn-danger">
                        <i class="bi bi-google me-2"></i> Sign in using Google
                    </a>
                </div>
                <!-- /.social-auth-links -->

                <p class="mb-1">
                    <a href="forgot-password.html">I forgot my password</a>
                </p>
                <p class="mb-0">
                    <a href="register.html" class="text-center"> Register a new membership </a>
                </p>
            </div>
            <!-- /.login-card-body -->
        </div>
    </main>
@endsection

@section('scripts')
 <script>
        document.querySelectorAll('.email-change-btn').forEach(button => {
            button.addEventListener('click', () => {
                document.querySelector('#loginEmail').value = button.dataset.email;
            })
        });
    </script>
@endsection