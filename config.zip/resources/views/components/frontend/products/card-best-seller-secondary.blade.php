@props(['product'])

<div class="col-md-6 col-lg-6 col-xl-3">
    <div class="text-center">

        <a href="{{ route('frontend.products.show', $product) }}">
        <img src="{{ productImage($product) }}" class="img-fluid rounded" alt="{{ $product->name }}">
        </a>

        <div class="py-4">
            <a href="{{ route('frontend.products.show', $product) }}" class="h5">{{ $product->name }}</a>
            <div class="d-flex my-3 justify-content-center">
                <i class="fas fa-star text-primary"></i>
                <i class="fas fa-star text-primary"></i>
                <i class="fas fa-star text-primary"></i>
                <i class="fas fa-star text-primary"></i>
                <i class="fas fa-star"></i>
            </div>
            <h4 class="mb-3">{{ $product->base_price }} $</h4>
            <x-frontend.buttons.add-to-card :product="$product" />
        </div>
    </div>
</div>
