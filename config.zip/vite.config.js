import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';

export default defineConfig({
    plugins: [
        laravel({
            input: [
                'resources/css/app.css', 
                'resources/css/adminlte.css', 
                'resources/js/adminlte.js', 
                'resources/js/filepond.js', 
                'resources/js/cart.js', 
                'resources/js/app.js',
                ],
            refresh: true,
        }),
    ],
});
